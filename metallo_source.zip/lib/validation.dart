class MovementValidation {
  static String? transfer(int quantity, String? origin, String? destination) {
    if (quantity <= 0) return 'invalid_quantity';
    if (origin == null || destination == null) return 'missing_team';
    if (origin == destination) return 'same_team';
    return null;
  }
}
