String? validatePositiveQuantity(int? value) {
  if (value == null || value <= 0) return 'A quantidade deve ser maior que zero.';
  return null;
}

String? validateRequired(String? value, String label) {
  if (value == null || value.trim().isEmpty) return '$label é obrigatório.';
  return null;
}
