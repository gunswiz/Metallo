import 'package:supabase_flutter/supabase_flutter.dart';

class AppRepository {
  AppRepository(this.client);
  final SupabaseClient client;

  User? get user => client.auth.currentUser;
  Stream<AuthState> get authChanges => client.auth.onAuthStateChange;

  Future<void> signIn(String email, String password) async {
    await client.auth.signInWithPassword(
      email: email.trim().toLowerCase(),
      password: password,
    );
  }

  Future<void> signUpFirstAdmin(String name, String email, String password) async {
    final res = await client.auth.signUp(
      email: email.trim().toLowerCase(),
      password: password,
      data: {'full_name': name.trim()},
    );
    if (res.user == null) throw const AuthException('Falha ao criar usuário.');
    if (res.session != null) await claimInitialAdmin();
  }

  Future<void> claimInitialAdmin() async {
    await client.rpc('claim_initial_admin');
  }

  Future<void> signOut() async {
    await client.auth.signOut();
  }

  Future<Map<String, dynamic>> profile() async {
    final id = user?.id;
    if (id == null) throw const AuthException('Sessão ausente.');
    return await client.from('profiles').select().eq('id', id).single();
  }

  Future<List<Map<String, dynamic>>> teams() async =>
      List<Map<String, dynamic>>.from(
        await client.from('teams').select().eq('active', true).order('name'),
      );

  Future<List<Map<String, dynamic>>> items() async =>
      List<Map<String, dynamic>>.from(
        await client.from('items').select().eq('active', true).order('name'),
      );

  Stream<List<Map<String, dynamic>>> inventory() => client
      .from('inventory')
      .stream(primaryKey: ['id'])
      .order('updated_at', ascending: false);

  Stream<List<Map<String, dynamic>>> assets() => client
      .from('assets')
      .stream(primaryKey: ['id'])
      .order('updated_at', ascending: false);

  Stream<List<Map<String, dynamic>>> movements() => client
      .from('movements')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false)
      .limit(100);

  Stream<List<Map<String, dynamic>>> assetMovements() => client
      .from('asset_movements')
      .stream(primaryKey: ['id'])
      .order('created_at', ascending: false)
      .limit(100);

  Future<void> transferMaterial({
    required String itemId,
    required int quantity,
    required String originTeamId,
    required String destinationTeamId,
    String? note,
  }) async {
    await client.rpc('register_movement', params: {
      'p_item_id': itemId,
      'p_movement_type': 'transfer',
      'p_quantity': quantity,
      'p_origin_team_id': originTeamId,
      'p_destination_team_id': destinationTeamId,
      'p_note': note,
    });
  }

  Future<void> transferAsset({
    required String assetId,
    required String destinationTeamId,
    String newStatus = 'available',
    String? note,
  }) async {
    await client.rpc('register_asset_movement', params: {
      'p_asset_id': assetId,
      'p_movement_type': 'transfer',
      'p_destination_team_id': destinationTeamId,
      'p_new_status': newStatus,
      'p_note': note,
    });
  }

  Future<void> updateAssetStatus({
    required String assetId,
    required String newStatus,
    String? note,
  }) async {
    await client.rpc('register_asset_movement', params: {
      'p_asset_id': assetId,
      'p_movement_type': 'status_change',
      'p_new_status': newStatus,
      'p_note': note,
    });
  }

  Future<void> createTeam(String name) async {
    await client.from('teams').insert({'name': name.trim()});
  }

  Future<void> createItem(
    String code,
    String name,
    String type, {
    String unit = 'un',
  }) async {
    await client.from('items').insert({
      'code': code.trim().toUpperCase(),
      'name': name.trim(),
      'item_type': type,
      'unit': unit.trim().isEmpty ? 'un' : unit.trim(),
    });
  }

  Future<void> createAsset(String itemId, String assetCode, String? teamId) async {
    await client.from('assets').insert({
      'item_id': itemId,
      'asset_code': assetCode.trim().toUpperCase(),
      'team_id': teamId,
      'status': 'available',
    });
  }

  Future<Map<String, dynamic>> createUser({
    required String email,
    required String fullName,
    required String role,
    required String temporaryPassword,
    String? teamId,
  }) async {
    final res = await client.functions.invoke('admin-invite-user', body: {
      'email': email.trim().toLowerCase(),
      'full_name': fullName.trim(),
      'role': role,
      'team_id': teamId,
      'temporary_password': temporaryPassword,
    });
    if (res.status < 200 || res.status >= 300) {
      throw Exception('${res.data}');
    }
    return Map<String, dynamic>.from(res.data as Map);
  }
}
