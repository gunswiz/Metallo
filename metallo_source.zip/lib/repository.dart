\
import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';

class Team {
  final String id;
  final String name;
  final String? description;
  Team({required this.id, required this.name, this.description});

  factory Team.fromMap(Map<String, dynamic> m) => Team(
        id: m['id'] as String,
        name: m['name'] as String,
        description: m['description'] as String?,
      );
}

class MaterialStock {
  final String inventoryId;
  final String itemId;
  final String teamId;
  final String code;
  final String name;
  final String unit;
  final int quantity;
  final String status;

  MaterialStock({
    required this.inventoryId,
    required this.itemId,
    required this.teamId,
    required this.code,
    required this.name,
    required this.unit,
    required this.quantity,
    required this.status,
  });

  factory MaterialStock.fromMap(Map<String, dynamic> m) {
    final item = Map<String, dynamic>.from(m['items'] as Map);
    return MaterialStock(
      inventoryId: m['id'] as String,
      itemId: m['item_id'] as String,
      teamId: m['team_id'] as String,
      code: item['code'] as String,
      name: item['name'] as String,
      unit: (item['unit'] as String?) ?? 'un',
      quantity: (m['quantity'] as num?)?.toInt() ?? 0,
      status: (m['status'] as String?) ?? 'available',
    );
  }
}

class EquipmentAsset {
  final String id;
  final String itemId;
  final String teamId;
  final String code;
  final String name;
  final String assetCode;
  final String? serialNumber;
  final String status;

  EquipmentAsset({
    required this.id,
    required this.itemId,
    required this.teamId,
    required this.code,
    required this.name,
    required this.assetCode,
    this.serialNumber,
    required this.status,
  });

  factory EquipmentAsset.fromMap(Map<String, dynamic> m) {
    final item = Map<String, dynamic>.from(m['items'] as Map);
    return EquipmentAsset(
      id: m['id'] as String,
      itemId: m['item_id'] as String,
      teamId: m['team_id'] as String,
      code: item['code'] as String,
      name: item['name'] as String,
      assetCode: m['asset_code'] as String,
      serialNumber: m['serial_number'] as String?,
      status: (m['status'] as String?) ?? 'available',
    );
  }
}

class DashboardSnapshot {
  final List<Team> teams;
  final List<MaterialStock> materials;
  final List<EquipmentAsset> equipment;

  DashboardSnapshot({
    required this.teams,
    required this.materials,
    required this.equipment,
  });
}

class MetalloRepository {
  MetalloRepository(this.client);
  final SupabaseClient client;
  RealtimeChannel? _channel;
  Timer? _debounce;

  Future<Map<String, dynamic>?> currentProfile() async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) return null;
    final result = await client
        .from('profiles')
        .select('id,full_name,role,active,team_id')
        .eq('id', uid)
        .maybeSingle();
    return result;
  }

  Future<DashboardSnapshot> fetchDashboard() async {
    final teamsRaw = await client
        .from('teams')
        .select('id,name,description,active')
        .eq('active', true)
        .order('created_at');

    final inventoryRaw = await client
        .from('inventory')
        .select(
          'id,item_id,team_id,quantity,status,items!inner(id,code,name,unit,item_type,active)',
        )
        .eq('items.item_type', 'material')
        .eq('items.active', true)
        .gt('quantity', 0)
        .order('created_at');

    final assetsRaw = await client
        .from('assets')
        .select(
          'id,item_id,asset_code,serial_number,team_id,status,active,items!inner(id,code,name,item_type,active)',
        )
        .eq('active', true)
        .eq('items.item_type', 'equipment')
        .eq('items.active', true)
        .not('team_id', 'is', null)
        .order('created_at');

    return DashboardSnapshot(
      teams: (teamsRaw as List)
          .map((e) => Team.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      materials: (inventoryRaw as List)
          .map((e) => MaterialStock.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      equipment: (assetsRaw as List)
          .map((e) => EquipmentAsset.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }

  Stream<DashboardSnapshot> watchDashboard() {
    late StreamController<DashboardSnapshot> controller;

    Future<void> reload() async {
      try {
        final data = await fetchDashboard();
        if (!controller.isClosed) controller.add(data);
      } catch (e, st) {
        if (!controller.isClosed) controller.addError(e, st);
      }
    }

    void scheduleReload() {
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 180), reload);
    }

    controller = StreamController<DashboardSnapshot>(
      onListen: () async {
        await reload();
        _channel?.unsubscribe();
        _channel = client
            .channel('metallo-dashboard-${DateTime.now().millisecondsSinceEpoch}')
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'teams',
              callback: (_) => scheduleReload(),
            )
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'items',
              callback: (_) => scheduleReload(),
            )
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'inventory',
              callback: (_) => scheduleReload(),
            )
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'assets',
              callback: (_) => scheduleReload(),
            )
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'movements',
              callback: (_) => scheduleReload(),
            )
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'asset_movements',
              callback: (_) => scheduleReload(),
            );
        _channel!.subscribe();
      },
      onCancel: () async {
        _debounce?.cancel();
        await _channel?.unsubscribe();
        _channel = null;
      },
    );

    return controller.stream;
  }

  Future<void> createTeam({
    required String name,
    String? description,
  }) async {
    final count = await client
        .from('teams')
        .select('id')
        .eq('active', true);
    if ((count as List).length >= 4) {
      throw Exception('O limite é de 4 equipes.');
    }
    await client.from('teams').insert({
      'name': name.trim(),
      'description': description?.trim().isEmpty == true ? null : description?.trim(),
      'active': true,
    });
  }

  Future<void> createMaterial({
    required String code,
    required String name,
    required String teamId,
    required int quantity,
    String unit = 'un',
    String? category,
    String? description,
  }) async {
    await client.rpc('create_material_for_team', params: {
      'p_code': code.trim(),
      'p_name': name.trim(),
      'p_description': _nullable(description),
      'p_category': _nullable(category),
      'p_unit': unit.trim().isEmpty ? 'un' : unit.trim(),
      'p_minimum_stock': 0,
      'p_team_id': teamId,
      'p_quantity': quantity,
    });
  }

  Future<void> createEquipment({
    required String code,
    required String name,
    required String assetCode,
    required String teamId,
    String? serialNumber,
    String? category,
    String? description,
    String? notes,
  }) async {
    await client.rpc('create_equipment_for_team', params: {
      'p_code': code.trim(),
      'p_name': name.trim(),
      'p_asset_code': assetCode.trim(),
      'p_serial_number': _nullable(serialNumber),
      'p_description': _nullable(description),
      'p_category': _nullable(category),
      'p_team_id': teamId,
      'p_notes': _nullable(notes),
    });
  }

  Future<void> transferMaterial({
    required String itemId,
    required String fromTeamId,
    required String toTeamId,
    required int quantity,
  }) async {
    await client.rpc('register_movement', params: {
      'p_item_id': itemId,
      'p_movement_type': 'transfer',
      'p_quantity': quantity,
      'p_origin_team_id': fromTeamId,
      'p_destination_team_id': toTeamId,
      'p_note': 'Transferência pelo aplicativo',
    });
  }

  Future<void> transferEquipment({
    required String assetId,
    required String toTeamId,
  }) async {
    await client.rpc('register_asset_movement', params: {
      'p_asset_id': assetId,
      'p_movement_type': 'transfer',
      'p_destination_team_id': toTeamId,
      'p_new_status': 'available',
      'p_note': 'Transferência pelo aplicativo',
    });
  }

  Future<List<Map<String, dynamic>>> fetchHistory() async {
    final material = await client
        .from('movements')
        .select(
          'id,created_at,quantity,movement_type,note,items(name,code),origin:origin_team_id(name),destination:destination_team_id(name)',
        )
        .order('created_at', ascending: false)
        .limit(40);

    final assets = await client
        .from('asset_movements')
        .select(
          'id,created_at,movement_type,new_status,note,assets(asset_code,items(name,code)),origin:origin_team_id(name),destination:destination_team_id(name)',
        )
        .order('created_at', ascending: false)
        .limit(40);

    final rows = <Map<String, dynamic>>[];
    for (final e in material as List) {
      rows.add({...Map<String, dynamic>.from(e as Map), '_kind': 'material'});
    }
    for (final e in assets as List) {
      rows.add({...Map<String, dynamic>.from(e as Map), '_kind': 'equipment'});
    }
    rows.sort((a, b) {
      final ad = DateTime.tryParse(a['created_at']?.toString() ?? '') ?? DateTime(1970);
      final bd = DateTime.tryParse(b['created_at']?.toString() ?? '') ?? DateTime(1970);
      return bd.compareTo(ad);
    });
    return rows.take(60).toList();
  }

  String? _nullable(String? value) {
    final v = value?.trim();
    return (v == null || v.isEmpty) ? null : v;
  }
}
