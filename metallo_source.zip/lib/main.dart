import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'repository.dart';
import 'validation.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabasePublishableKey,
  );
  runApp(const MetalloApp());
}

class MetalloApp extends StatelessWidget {
  const MetalloApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF1687FF),
      brightness: Brightness.dark,
    ).copyWith(
      primary: const Color(0xFF1687FF),
      secondary: const Color(0xFF55A9FF),
      surface: const Color(0xFF111318),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Metallo',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: scheme,
        scaffoldBackgroundColor: Colors.black,
        cardColor: const Color(0xFF111318),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: const Color(0xFF0E1116),
          indicatorColor: scheme.primary.withValues(alpha: .22),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF12151B),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF30343D)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF30343D)),
          ),
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF111318),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Supabase.instance.client.auth;
    return StreamBuilder<AuthState>(
      stream: auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (auth.currentSession == null) return const LoginPage();
        return const MainShell();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> _login() async {
    if (loading) return;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
    } catch (e) {
      if (mounted) setState(() => error = _friendlyError(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        minimum: const EdgeInsets.all(24),
        child: Center(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.inventory_2_rounded,
                      size: 66, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 18),
                  const Text('Metallo',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  const Text('Almoxarifado online por equipes',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 34),
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                        labelText: 'E-mail', prefixIcon: Icon(Icons.email_outlined)),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: password,
                    obscureText: true,
                    onSubmitted: (_) => _login(),
                    decoration: const InputDecoration(
                        labelText: 'Senha', prefixIcon: Icon(Icons.lock_outline)),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 14),
                    Text(error!,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.error)),
                  ],
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: loading ? null : _login,
                    child: loading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('Entrar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  late final MetalloRepository repo =
      MetalloRepository(Supabase.instance.client);
  late final Stream<DashboardSnapshot> dashboard = repo.watchDashboard();

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(repo: repo, stream: dashboard),
      MaterialsPage(repo: repo, stream: dashboard),
      EquipmentPage(repo: repo, stream: dashboard),
      HistoryPage(repo: repo),
    ];

    return Scaffold(
      appBar: AppBar(
        title: FutureBuilder<Map<String, dynamic>?>(
          future: repo.currentProfile(),
          builder: (context, snap) {
            final name = snap.data?['full_name']?.toString();
            return Text(name == null ? 'Metallo' : 'Olá, ${_firstName(name)}');
          },
        ),
        actions: [
          IconButton(
            tooltip: 'Equipes',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => TeamsPage(repo: repo)),
            ),
            icon: const Icon(Icons.groups_2_outlined),
          ),
          IconButton(
            tooltip: 'Atualizar',
            onPressed: () => setState(() {}),
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'Sair',
            onPressed: () => Supabase.instance.client.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(
              icon: Icon(Icons.inventory_2_outlined), label: 'Materiais'),
          NavigationDestination(
              icon: Icon(Icons.handyman_outlined), label: 'Equipamentos'),
          NavigationDestination(
              icon: Icon(Icons.history_rounded), label: 'Histórico'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.repo, required this.stream});
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final data = snap.data!;
        if (data.teams.isEmpty) {
          return EmptyState(
            icon: Icons.groups_2_outlined,
            title: 'Crie as equipes primeiro',
            subtitle:
                'Cada material e equipamento ficará sempre vinculado a uma equipe.',
            buttonText: 'Gerenciar equipes',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => TeamsPage(repo: repo)),
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () async { await repo.fetchDashboard(); },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF111925), Color(0xFF07111E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: const Color(0xFF1A5FA8)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1687FF).withValues(alpha: .14),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(
                            Icons.inventory_2_outlined,
                            color: Color(0xFF3A9DFF),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'METALLO',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2.2,
                                ),
                              ),
                              Text(
                                'Gestão de materiais e equipamentos',
                                style: TextStyle(color: Colors.white60),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1687FF).withValues(alpha: .15),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'Admin',
                            style: TextStyle(
                              color: Color(0xFF66B3FF),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: _SummaryMetric(
                            icon: Icons.groups_2_outlined,
                            value: '${data.teams.length}/4',
                            label: 'Equipes',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _SummaryMetric(
                            icon: Icons.inventory_2_outlined,
                            value: '${data.materials.length}',
                            label: 'Materiais',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _SummaryMetric(
                            icon: Icons.handyman_outlined,
                            value: '${data.equipment.length}',
                            label: 'Equipamentos',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'Equipes e inventário',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 5),
              Text(
                'Veja rapidamente onde cada item está e cadastre diretamente na equipe responsável.',
                style: TextStyle(color: Colors.white.withValues(alpha: .65)),
              ),
              const SizedBox(height: 16),
              for (final team in data.teams)
                TeamCard(
                  team: team,
                  materials: data.materials
                      .where((m) => m.teamId == team.id)
                      .toList(),
                  equipment: data.equipment
                      .where((e) => e.teamId == team.id)
                      .toList(),
                  onAddMaterial: () =>
                      showMaterialDialog(context, repo, data.teams, team.id),
                  onAddEquipment: () =>
                      showEquipmentDialog(context, repo, data.teams, team.id),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _SummaryMetric extends StatelessWidget {
  const _SummaryMetric({
    required this.icon,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
      decoration: BoxDecoration(
        color: const Color(0xFF151D28),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF253346)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: const Color(0xFF3A9DFF)),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class TeamCard extends StatelessWidget {
  const TeamCard({
    super.key,
    required this.team,
    required this.materials,
    required this.equipment,
    required this.onAddMaterial,
    required this.onAddEquipment,
  });

  final Team team;
  final List<MaterialStock> materials;
  final List<EquipmentAsset> equipment;
  final VoidCallback onAddMaterial;
  final VoidCallback onAddEquipment;

  @override
  Widget build(BuildContext context) {
    final blue = Theme.of(context).colorScheme.primary;
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
              backgroundColor: blue.withValues(alpha: .18),
              child: Icon(Icons.groups_2, color: blue),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(team.name,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800)),
            ),
            Text('${materials.length} mat. • ${equipment.length} eq.',
                style: const TextStyle(color: Colors.white60)),
          ]),
          const SizedBox(height: 14),
          _sectionTitle(context, Icons.inventory_2_outlined, 'Materiais'),
          if (materials.isEmpty)
            const _SmallEmpty(text: 'Nenhum material nesta equipe.')
          else
            for (final m in materials.take(6))
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(m.name),
                subtitle: Text('Código ${m.code}'),
                trailing: Text('${m.quantity} ${m.unit}',
                    style: TextStyle(
                        color: blue, fontWeight: FontWeight.w700)),
              ),
          const Divider(height: 22),
          _sectionTitle(context, Icons.handyman_outlined, 'Equipamentos'),
          if (equipment.isEmpty)
            const _SmallEmpty(text: 'Nenhum equipamento nesta equipe.')
          else
            for (final e in equipment.take(6))
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(e.name),
                subtitle: Text('Patrimônio ${e.assetCode}'),
                trailing: StatusChip(status: e.status),
              ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onAddMaterial,
                icon: const Icon(Icons.add_box_outlined),
                label: const Text('Material'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.tonalIcon(
                onPressed: onAddEquipment,
                icon: const Icon(Icons.add),
                label: const Text('Equipamento'),
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, IconData icon, String text) {
    return Row(children: [
      Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
      const SizedBox(width: 8),
      Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
    ]);
  }
}

class MaterialsPage extends StatelessWidget {
  const MaterialsPage({super.key, required this.repo, required this.stream});
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: data.teams.isEmpty
                ? null
                : () => showMaterialDialog(context, repo, data.teams, null),
            icon: const Icon(Icons.add),
            label: const Text('Novo material'),
          ),
          body: data.materials.isEmpty
              ? const EmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'Nenhum material em estoque',
                  subtitle: 'Cadastre o material já selecionando a equipe.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: data.materials.length,
                  itemBuilder: (context, i) {
                    final m = data.materials[i];
                    final team =
                        data.teams.where((t) => t.id == m.teamId).firstOrNull;
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.inventory_2_outlined),
                        title: Text(m.name),
                        subtitle: Text(
                            '${team?.name ?? 'Equipe'} • código ${m.code}'),
                        trailing: Text('${m.quantity} ${m.unit}',
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w800)),
                        onTap: () => showMaterialTransferDialog(
                            context, repo, data.teams, m),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}

class EquipmentPage extends StatelessWidget {
  const EquipmentPage({super.key, required this.repo, required this.stream});
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: data.teams.isEmpty
                ? null
                : () => showEquipmentDialog(context, repo, data.teams, null),
            icon: const Icon(Icons.add),
            label: const Text('Novo equipamento'),
          ),
          body: data.equipment.isEmpty
              ? const EmptyState(
                  icon: Icons.handyman_outlined,
                  title: 'Nenhum equipamento',
                  subtitle:
                      'Cadastre o equipamento já selecionando a equipe responsável.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: data.equipment.length,
                  itemBuilder: (context, i) {
                    final e = data.equipment[i];
                    final team =
                        data.teams.where((t) => t.id == e.teamId).firstOrNull;
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.handyman_outlined),
                        title: Text(e.name),
                        subtitle: Text(
                            '${team?.name ?? 'Equipe'} • patrimônio ${e.assetCode}'),
                        trailing: StatusChip(status: e.status),
                        onTap: () => showEquipmentTransferDialog(
                            context, repo, data.teams, e),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}

class TeamsPage extends StatefulWidget {
  const TeamsPage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<TeamsPage> createState() => _TeamsPageState();
}

class _TeamsPageState extends State<TeamsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Equipes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createTeam(context),
        icon: const Icon(Icons.add),
        label: const Text('Criar equipe'),
      ),
      body: FutureBuilder<DashboardSnapshot>(
        future: widget.repo.fetchDashboard(),
        builder: (context, snap) {
          if (snap.hasError) return ErrorState(error: snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final teams = snap.data!.teams;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('${teams.length}/4 equipes criadas',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              for (final t in teams)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.groups_2_outlined),
                    title: Text(t.name),
                    subtitle: t.description == null ? null : Text(t.description!),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _createTeam(BuildContext context) async {
    final name = TextEditingController();
    final desc = TextEditingController();
    bool busy = false;
    String? error;

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Nova equipe'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
            const SizedBox(height: 10),
            TextField(
                controller: desc,
                decoration: const InputDecoration(labelText: 'Descrição (opcional)')),
            if (error != null) ...[
              const SizedBox(height: 10),
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ]
          ]),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(dialogContext),
                child: const Text('Cancelar')),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (name.text.trim().isEmpty) {
                        setLocal(() => error = 'Informe o nome da equipe.');
                        return;
                      }
                      setLocal(() {
                        busy = true;
                        error = null;
                      });
                      try {
                        await widget.repo.createTeam(
                            name: name.text, description: desc.text);
                        if (dialogContext.mounted) Navigator.pop(dialogContext);
                        if (mounted) setState(() {});
                      } catch (e) {
                        setLocal(() => error = _friendlyError(e));
                      } finally {
                        if (dialogContext.mounted) setLocal(() => busy = false);
                      }
                    },
              child: busy
                  ? const SizedBox(
                      width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Criar'),
            )
          ],
        ),
      ),
    );
  }
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<Map<String, dynamic>>> future;

  @override
  void initState() {
    super.initState();
    future = widget.repo.fetchHistory();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.isEmpty) {
          return const EmptyState(
            icon: Icons.history_rounded,
            title: 'Histórico vazio',
            subtitle: 'As entradas e transferências aparecerão aqui.',
          );
        }

        return RefreshIndicator(
          onRefresh: () async {
            setState(() => future = widget.repo.fetchHistory());
            await future;
          },
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: snap.data!.length,
            itemBuilder: (context, i) {
              final row = snap.data![i];
              final isMaterial = row['_kind'] == 'material';
              final title = isMaterial
                  ? ((row['items'] as Map?)?['name']?.toString() ?? 'Material')
                  : (((row['assets'] as Map?)?['items'] as Map?)?['name']
                          ?.toString() ??
                      'Equipamento');
              final origin = (row['origin'] as Map?)?['name']?.toString();
              final destination =
                  (row['destination'] as Map?)?['name']?.toString();
              return Card(
                child: ListTile(
                  leading: Icon(isMaterial
                      ? Icons.inventory_2_outlined
                      : Icons.handyman_outlined),
                  title: Text(title),
                  subtitle: Text([
                    row['movement_type']?.toString() ?? '',
                    if (origin != null) 'de $origin',
                    if (destination != null) 'para $destination',
                  ].where((e) => e.isNotEmpty).join(' • ')),
                ),
              );
            },
          ),
        );
      },
    );
  }
}

Future<void> showMaterialDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  String? initialTeamId,
) async {
  final code = TextEditingController();
  final name = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final unit = TextEditingController(text: 'un');
  String? teamId = initialTeamId ?? (teams.isNotEmpty ? teams.first.id : null);
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Novo material'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: code, decoration: const InputDecoration(labelText: 'Código')),
            const SizedBox(height: 10),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Material')),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: teamId,
              decoration: const InputDecoration(labelText: 'Equipe'),
              items: teams
                  .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                  .toList(),
              onChanged: busy ? null : (v) => setLocal(() => teamId = v),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: quantity,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Quantidade'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: unit,
                  decoration: const InputDecoration(labelText: 'Unidade'),
                ),
              ),
            ]),
            if (error != null) ...[
              const SizedBox(height: 10),
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ]),
        ),
        actions: [
          TextButton(
              onPressed: busy ? null : () => Navigator.pop(dialogContext),
              child: const Text('Cancelar')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final qty = int.tryParse(quantity.text.trim());
                    final validation = validateRequired(code.text, 'Código') ??
                        validateRequired(name.text, 'Material') ??
                        (teamId == null ? 'Selecione a equipe.' : null) ??
                        validatePositiveQuantity(qty);
                    if (validation != null) {
                      setLocal(() => error = validation);
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.createMaterial(
                        code: code.text,
                        name: name.text,
                        teamId: teamId!,
                        quantity: qty!,
                        unit: unit.text,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = _friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Criar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showEquipmentDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  String? initialTeamId,
) async {
  final code = TextEditingController();
  final name = TextEditingController();
  final assetCode = TextEditingController();
  final serial = TextEditingController();
  String? teamId = initialTeamId ?? (teams.isNotEmpty ? teams.first.id : null);
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Novo equipamento'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: code, decoration: const InputDecoration(labelText: 'Código do tipo')),
            const SizedBox(height: 10),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Equipamento')),
            const SizedBox(height: 10),
            TextField(controller: assetCode, decoration: const InputDecoration(labelText: 'Patrimônio / identificação')),
            const SizedBox(height: 10),
            TextField(controller: serial, decoration: const InputDecoration(labelText: 'Número de série (opcional)')),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: teamId,
              decoration: const InputDecoration(labelText: 'Equipe'),
              items: teams
                  .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                  .toList(),
              onChanged: busy ? null : (v) => setLocal(() => teamId = v),
            ),
            if (error != null) ...[
              const SizedBox(height: 10),
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ]),
        ),
        actions: [
          TextButton(
              onPressed: busy ? null : () => Navigator.pop(dialogContext),
              child: const Text('Cancelar')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final validation = validateRequired(code.text, 'Código') ??
                        validateRequired(name.text, 'Equipamento') ??
                        validateRequired(assetCode.text, 'Patrimônio') ??
                        (teamId == null ? 'Selecione a equipe.' : null);
                    if (validation != null) {
                      setLocal(() => error = validation);
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.createEquipment(
                        code: code.text,
                        name: name.text,
                        assetCode: assetCode.text,
                        serialNumber: serial.text,
                        teamId: teamId!,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = _friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Criar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showMaterialTransferDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  MaterialStock material,
) async {
  final destinations = teams.where((t) => t.id != material.teamId).toList();
  if (destinations.isEmpty) return;
  String teamId = destinations.first.id;
  final qty = TextEditingController(text: '1');
  String? error;
  bool busy = false;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text('Transferir ${material.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(
            initialValue: teamId,
            decoration: const InputDecoration(labelText: 'Equipe de destino'),
            items: destinations
                .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                .toList(),
            onChanged: busy ? null : (v) => setLocal(() => teamId = v!),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: qty,
            keyboardType: TextInputType.number,
            decoration:
                InputDecoration(labelText: 'Quantidade (máx. ${material.quantity})'),
          ),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ]
        ]),
        actions: [
          TextButton(
              onPressed: busy ? null : () => Navigator.pop(dialogContext),
              child: const Text('Cancelar')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final value = int.tryParse(qty.text);
                    if (value == null || value <= 0 || value > material.quantity) {
                      setLocal(() => error = 'Informe uma quantidade válida.');
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.transferMaterial(
                          itemId: material.itemId,
                          fromTeamId: material.teamId,
                          toTeamId: teamId,
                          quantity: value);
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = _friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Transferir'),
          )
        ],
      ),
    ),
  );
}

Future<void> showEquipmentTransferDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  EquipmentAsset equipment,
) async {
  final destinations = teams.where((t) => t.id != equipment.teamId).toList();
  if (destinations.isEmpty) return;
  String teamId = destinations.first.id;
  String? error;
  bool busy = false;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text('Transferir ${equipment.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(
            initialValue: teamId,
            decoration: const InputDecoration(labelText: 'Equipe de destino'),
            items: destinations
                .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                .toList(),
            onChanged: busy ? null : (v) => setLocal(() => teamId = v!),
          ),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ]
        ]),
        actions: [
          TextButton(
              onPressed: busy ? null : () => Navigator.pop(dialogContext),
              child: const Text('Cancelar')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.transferEquipment(
                          assetId: equipment.id, toTeamId: teamId);
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = _friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Transferir'),
          )
        ],
      ),
    ),
  );
}

class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    final label = {
          'available': 'Disponível',
          'in_use': 'Em uso',
          'maintenance': 'Manutenção',
          'damaged': 'Danificado',
          'lost': 'Perdido',
          'retired': 'Baixado',
        }[status] ??
        status;
    return Chip(label: Text(label));
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.buttonText,
    this.onPressed,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String? buttonText;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(children: [
          Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 14),
          Text(title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60)),
          if (buttonText != null && onPressed != null) ...[
            const SizedBox(height: 18),
            FilledButton(onPressed: onPressed, child: Text(buttonText!)),
          ]
        ]),
      ),
    );
  }
}

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.error});
  final Object? error;

  @override
  Widget build(BuildContext context) {
    return EmptyState(
      icon: Icons.error_outline,
      title: 'Não foi possível carregar',
      subtitle: _friendlyError(error),
    );
  }
}

class _SmallEmpty extends StatelessWidget {
  const _SmallEmpty({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Text(text, style: const TextStyle(color: Colors.white54)),
      );
}

String _friendlyError(Object? error) {
  final text = error.toString();
  if (text.contains('duplicate key') || text.contains('23505')) {
    return 'Esse código já está cadastrado. Use um código diferente.';
  }
  if (text.contains('admin_required')) {
    return 'Apenas o administrador pode realizar esta operação.';
  }
  if (text.contains('invalid_team') || text.contains('team_required')) {
    return 'Selecione uma equipe válida.';
  }
  if (text.contains('insufficient_stock')) {
    return 'Quantidade insuficiente na equipe de origem.';
  }
  if (text.contains('SocketException') || text.contains('Failed host lookup')) {
    return 'Sem conexão com o servidor. Verifique a internet e tente novamente.';
  }
  return text.replaceFirst('Exception: ', '');
}

String _firstName(String name) {
  final clean = name.trim();
  if (clean.isEmpty) return 'Administrador';
  return clean.split(RegExp(r'\s+')).first;
}

extension FirstOrNullX<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
