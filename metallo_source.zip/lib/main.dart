import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'repository.dart';
import 'validation.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabasePublishableKey,
  );
  runApp(const MetalloApp());
}

class MetalloApp extends StatelessWidget {
  const MetalloApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF1687FF),
      brightness: Brightness.dark,
    ).copyWith(
      primary: const Color(0xFF1687FF),
      secondary: const Color(0xFF55A9FF),
      surface: const Color(0xFF111720),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Metallo',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFF05080D),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF05080D),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF111720),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF121820),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF2B394B)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF2B394B)),
          ),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF090D13),
          indicatorColor: Color(0xFF123A65),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class BrandLogo extends StatelessWidget {
  const BrandLogo({super.key, this.height = 86});
  final double height;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/metallo_logo_outline.png',
      height: height,
      fit: BoxFit.contain,
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Supabase.instance.client.auth;
    return StreamBuilder<AuthState>(
      stream: auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (snapshot.data?.event == AuthChangeEvent.passwordRecovery) {
          return const ResetPasswordPage();
        }
        if (auth.currentSession == null) return const LoginPage();
        return const ProfileGate();
      },
    );
  }
}

class ProfileGate extends StatefulWidget {
  const ProfileGate({super.key});

  @override
  State<ProfileGate> createState() => _ProfileGateState();
}

class _ProfileGateState extends State<ProfileGate> {
  late final MetalloRepository repo =
      MetalloRepository(Supabase.instance.client);
  late Future<Map<String, dynamic>?> profile = repo.currentProfile();

  @override
  void dispose() {
    repo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>?>(
      future: profile,
      builder: (context, snap) {
        if (snap.hasError) {
          return ErrorPage(
            message: friendlyError(snap.error),
            onRetry: () => setState(() => profile = repo.currentProfile()),
          );
        }
        if (!snap.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final p = snap.data!;
        if (p['active'] != true) {
          return PendingAccessPage(
            onRetry: () => setState(() => profile = repo.currentProfile()),
          );
        }
        return MainShell(profile: p);
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool createMode = false;
  bool loading = false;
  String? error;
  String? message;

  Future<void> submit() async {
    if (loading) return;
    setState(() {
      loading = true;
      error = null;
      message = null;
    });
    try {
      if (createMode) {
        if (name.text.trim().isEmpty) throw Exception('Informe seu nome.');
        if (password.text.length < 4) {
          throw Exception('A senha precisa ter pelo menos 4 caracteres.');
        }
        await Supabase.instance.client.auth.signUp(
          email: email.text.trim(),
          password: password.text,
          data: {'full_name': name.text.trim()},
        );
        await Supabase.instance.client.auth.signOut();
        if (mounted) {
          setState(() {
            createMode = false;
            message =
                'Conta criada. Aguarde o administrador liberar seu acesso e definir equipe/cargo.';
          });
        }
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> forgotPassword() async {
    final address = email.text.trim();
    if (address.isEmpty || !address.contains('@')) {
      setState(() => error = 'Informe seu e-mail para recuperar a senha.');
      return;
    }
    setState(() { loading = true; error = null; message = null; });
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(
        address,
        redirectTo: 'com.gunswiz.metallo://auth-callback/',
      );
      if (mounted) {
        setState(() => message = 'Enviamos um link de recuperação para $address.');
      }
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        minimum: const EdgeInsets.all(24),
        child: Center(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const BrandLogo(height: 105),
                  const SizedBox(height: 10),
                  Text(
                    createMode ? 'Criar nova conta' : 'Gestão de materiais e equipamentos',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.white70,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 28),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: false, label: Text('Entrar')),
                      ButtonSegment(value: true, label: Text('Criar conta')),
                    ],
                    selected: {createMode},
                    onSelectionChanged: loading
                        ? null
                        : (s) => setState(() {
                              createMode = s.first;
                              error = null;
                              message = null;
                            }),
                  ),
                  const SizedBox(height: 18),
                  if (createMode) ...[
                    TextField(
                      controller: name,
                      decoration: const InputDecoration(
                        labelText: 'Nome',
                        prefixIcon: Icon(Icons.person_outline),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'E-mail',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    onSubmitted: (_) => submit(),
                    decoration: InputDecoration(
                      labelText: createMode ? 'Senha (4+)' : 'Senha',
                      prefixIcon: const Icon(Icons.lock_outline),
                    ),
                  ),
                  if (!createMode)
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: loading ? null : forgotPassword,
                        child: const Text('Esqueci minha senha'),
                      ),
                    ),
                  if (message != null) ...[
                    const SizedBox(height: 14),
                    Text(
                      message!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFF67D39A)),
                    ),
                  ],
                  if (error != null) ...[
                    const SizedBox(height: 14),
                    Text(
                      error!,
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ],
                  const SizedBox(height: 18),
                  FilledButton(
                    onPressed: loading ? null : submit,
                    child: loading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text(createMode ? 'Criar conta' : 'Entrar'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ResetPasswordPage extends StatefulWidget {
  const ResetPasswordPage({super.key});

  @override
  State<ResetPasswordPage> createState() => _ResetPasswordPageState();
}

class _ResetPasswordPageState extends State<ResetPasswordPage> {
  final password = TextEditingController();
  final confirmPassword = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> save() async {
    if (password.text.length < 4) {
      setState(() => error = 'A nova senha precisa ter pelo menos 4 caracteres.');
      return;
    }
    if (password.text != confirmPassword.text) {
      setState(() => error = 'As senhas não são iguais.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      await Supabase.instance.client.auth.updateUser(
        UserAttributes(password: password.text),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Senha alterada com sucesso.')),
        );
        await Supabase.instance.client.auth.signOut();
      }
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      minimum: const EdgeInsets.all(24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const BrandLogo(height: 96),
              const SizedBox(height: 24),
              const Text('Definir nova senha', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 18),
              TextField(controller: password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Nova senha (4+)')),
              const SizedBox(height: 12),
              TextField(controller: confirmPassword, obscureText: true,
                decoration: const InputDecoration(labelText: 'Confirmar nova senha')),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 18),
              FilledButton(onPressed: busy ? null : save,
                child: busy ? const CircularProgressIndicator(strokeWidth: 2) : const Text('Salvar nova senha')),
            ],
          ),
        ),
      ),
    ),
  );
}

class PendingAccessPage extends StatelessWidget {
  const PendingAccessPage({super.key, required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        minimum: const EdgeInsets.all(28),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const BrandLogo(height: 92),
              const SizedBox(height: 24),
              const Icon(Icons.hourglass_top_rounded, size: 60, color: Color(0xFF1687FF)),
              const SizedBox(height: 16),
              const Text(
                'Acesso aguardando liberação',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                'O administrador precisa definir sua equipe e seu cargo antes do primeiro acesso.',
                style: TextStyle(color: Colors.white60),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text('Verificar novamente'),
              ),
              TextButton(
                onPressed: () => Supabase.instance.client.auth.signOut(),
                child: const Text('Sair'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.profile});
  final Map<String, dynamic> profile;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  late final MetalloRepository repo =
      MetalloRepository(Supabase.instance.client);
  late final Stream<DashboardSnapshot> dashboard = repo.watchDashboard();

  String get role => widget.profile['role']?.toString() ?? 'collaborator';
  String? get userTeamId => widget.profile['team_id']?.toString();
  bool get isAdmin => role == 'admin';
  bool get canOperate => role == 'admin' || role == 'engineer' || role == 'leader';

  @override
  void dispose() {
    repo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(
        repo: repo,
        stream: dashboard,
        role: role,
        userTeamId: userTeamId,
      ),
      MaterialsPage(
        repo: repo,
        stream: dashboard,
        role: role,
        userTeamId: userTeamId,
      ),
      EquipmentPage(
        repo: repo,
        stream: dashboard,
        role: role,
        userTeamId: userTeamId,
      ),
      HistoryPage(repo: repo, stream: dashboard, isAdmin: isAdmin),
    ];

    final name = widget.profile['full_name']?.toString() ?? 'Usuário';

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(
          children: [
            Expanded(
              child: Text(
                'Olá, ${firstName(name)}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(width: 8),
            RoleBadge(role: role),
          ],
        ),
        actions: [
          if (isAdmin)
            IconButton(
              tooltip: 'Administração',
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AdministrationPage(repo: repo),
                ),
              ),
              icon: const Icon(Icons.admin_panel_settings_outlined),
            ),
          IconButton(
            tooltip: 'Minha conta',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const AccountSettingsPage()),
            ),
            icon: const Icon(Icons.account_circle_outlined),
          ),
          IconButton(
            tooltip: 'Atualizar',
            onPressed: repo.refreshDashboard,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'Sair',
            onPressed: () => Supabase.instance.client.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            label: 'Materiais',
          ),
          NavigationDestination(
            icon: Icon(Icons.handyman_outlined),
            label: 'Equipamentos',
          ),
          NavigationDestination(icon: Icon(Icons.history), label: 'Histórico'),
        ],
      ),
    );
  }
}

class AccountSettingsPage extends StatefulWidget {
  const AccountSettingsPage({super.key});

  @override
  State<AccountSettingsPage> createState() => _AccountSettingsPageState();
}

class _AccountSettingsPageState extends State<AccountSettingsPage> {
  late final TextEditingController email = TextEditingController(
    text: Supabase.instance.client.auth.currentUser?.email ?? '',
  );
  final password = TextEditingController();
  final password2 = TextEditingController();
  bool busy = false;
  String? message;
  String? error;

  Future<void> changeEmail() async {
    final value = email.text.trim();
    if (value.isEmpty || !value.contains('@')) {
      setState(() => error = 'Informe um e-mail válido.');
      return;
    }
    setState(() { busy = true; error = null; message = null; });
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(email: value));
      if (mounted) setState(() => message = 'Solicitação enviada. Confirme a alteração pelos e-mails de segurança enviados pelo Supabase.');
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> changePassword() async {
    if (password.text.length < 4) {
      setState(() => error = 'A nova senha precisa ter pelo menos 4 caracteres.');
      return;
    }
    if (password.text != password2.text) {
      setState(() => error = 'As senhas não são iguais.');
      return;
    }
    setState(() { busy = true; error = null; message = null; });
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(password: password.text));
      password.clear(); password2.clear();
      if (mounted) setState(() => message = 'Senha alterada com sucesso.');
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Minha conta')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const BrandLogo(height: 62),
        const SizedBox(height: 20),
        const Text('Alterar e-mail', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        TextField(controller: email, keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(labelText: 'Novo e-mail', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: busy ? null : changeEmail,
          icon: const Icon(Icons.mark_email_read_outlined), label: const Text('Solicitar alteração de e-mail')),
        const SizedBox(height: 26),
        const Text('Alterar senha', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        TextField(controller: password, obscureText: true,
          decoration: const InputDecoration(labelText: 'Nova senha (4+)')),
        const SizedBox(height: 10),
        TextField(controller: password2, obscureText: true,
          decoration: const InputDecoration(labelText: 'Confirmar nova senha')),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: busy ? null : changePassword,
          icon: const Icon(Icons.lock_reset), label: const Text('Alterar senha')),
        if (message != null) ...[
          const SizedBox(height: 14), Text(message!, style: const TextStyle(color: Color(0xFF67D39A))),
        ],
        if (error != null) ...[
          const SizedBox(height: 14), Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
        ],
      ],
    ),
  );
}

class RoleBadge extends StatelessWidget {
  const RoleBadge({super.key, required this.role});
  final String role;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFF0E3965),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2C8BE8)),
      ),
      child: Text(
        roleLabel(role),
        style: const TextStyle(
          color: Color(0xFF8CC8FF),
          fontWeight: FontWeight.w800,
          fontSize: 11,
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({
    super.key,
    required this.repo,
    required this.stream,
    required this.role,
    required this.userTeamId,
  });

  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;
  final String role;
  final String? userTeamId;

  bool get canOperate => role == 'admin' || role == 'engineer' || role == 'leader';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;

        return RefreshIndicator(
          onRefresh: repo.refreshDashboard,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF111A25), Color(0xFF07101B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: const Color(0xFF164C80)),
                ),
                child: Column(
                  children: [
                    const BrandLogo(height: 68),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: SummaryTile(
                            icon: Icons.groups_2_outlined,
                            value: '${data.teams.where((t) => !t.isCentral).length}',
                            label: 'Equipes',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SummaryTile(
                            icon: Icons.inventory_2_outlined,
                            value: '${data.materials.map((m) => m.itemId).toSet().length}',
                            label: 'Materiais',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SummaryTile(
                            icon: Icons.handyman_outlined,
                            value: '${data.equipment.length}',
                            label: 'Equipamentos',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Equipes e inventário',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              const Text(
                'Cada item aparece na equipe onde está fisicamente.',
                style: TextStyle(color: Colors.white60),
              ),
              const SizedBox(height: 14),
              for (final team in data.teams)
                TeamInventoryCard(
                  team: team,
                  materials: data.materials.where((m) => m.teamId == team.id).toList(),
                  equipment: data.equipment.where((e) => e.teamId == team.id).toList(),
                  canOperate: canOperate &&
                      (role == 'admin' || role == 'engineer' || team.id == userTeamId),
                  onAddMaterial: () => showMaterialDialog(
                    context,
                    repo,
                    role == 'leader'
                        ? data.teams.where((t) => t.id == userTeamId).toList()
                        : data.teams,
                    team.id,
                  ),
                  onAddEquipment: () => showEquipmentDialog(
                    context,
                    repo,
                    role == 'leader'
                        ? data.teams.where((t) => t.id == userTeamId).toList()
                        : data.teams,
                    team.id,
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class SummaryTile extends StatelessWidget {
  const SummaryTile({
    super.key,
    required this.icon,
    required this.value,
    required this.label,
  });
  final IconData icon;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF141C27),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: const Color(0xFF243449)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF3B9EFF), size: 19),
          const SizedBox(height: 7),
          Text(
            value,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
          ),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11, color: Colors.white60),
          ),
        ],
      ),
    );
  }
}

class TeamInventoryCard extends StatelessWidget {
  const TeamInventoryCard({
    super.key,
    required this.team,
    required this.materials,
    required this.equipment,
    required this.canOperate,
    required this.onAddMaterial,
    required this.onAddEquipment,
  });

  final Team team;
  final List<MaterialStock> materials;
  final List<EquipmentAsset> equipment;
  final bool canOperate;
  final VoidCallback onAddMaterial;
  final VoidCallback onAddEquipment;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Color(0xFF0E3157),
                  child: Icon(Icons.groups_2, color: Color(0xFF52A9FF)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    team.name,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                ),
                Text(
                  '${materials.length} mat. • ${equipment.length} eq.',
                  style: const TextStyle(color: Colors.white54),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text('Materiais', style: TextStyle(fontWeight: FontWeight.w800)),
            if (materials.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('Nenhum material.', style: TextStyle(color: Colors.white54)),
              )
            else
              for (final m in materials.take(5))
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(m.name),
                  subtitle: Text(m.code),
                  trailing: Text(
                    '${m.quantity} ${m.unit}',
                    style: const TextStyle(
                      color: Color(0xFF52A9FF),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            const Divider(),
            const Text('Equipamentos', style: TextStyle(fontWeight: FontWeight.w800)),
            if (equipment.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text('Nenhum equipamento.', style: TextStyle(color: Colors.white54)),
              )
            else
              for (final e in equipment.take(5))
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(e.name),
                  subtitle: Text('Patrimônio ${e.assetCode}'),
                  trailing: StatusBadge(status: e.status),
                ),
            if (canOperate) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: onAddMaterial,
                      icon: const Icon(Icons.add_box_outlined),
                      label: const Text('Material'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.tonalIcon(
                      onPressed: onAddEquipment,
                      icon: const Icon(Icons.add),
                      label: const Text('Equipamento'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class MaterialsPage extends StatelessWidget {
  const MaterialsPage({
    super.key,
    required this.repo,
    required this.stream,
    required this.role,
    required this.userTeamId,
  });
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;
  final String role;
  final String? userTeamId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        final canOperate = role == 'admin' || role == 'engineer' || role == 'leader';
        final allowedTeams = role == 'leader'
            ? data.teams.where((t) => t.id == userTeamId).toList()
            : data.teams;

        return Scaffold(
          backgroundColor: const Color(0xFF05080D),
          endDrawer: MaterialCatalogDrawer(repo: repo, isAdmin: role == 'admin'),
          floatingActionButton: canOperate && allowedTeams.isNotEmpty
              ? FloatingActionButton.extended(
                  onPressed: () => showMaterialDialog(
                    context, repo, allowedTeams, role == 'leader' ? userTeamId : null,
                  ),
                  icon: const Icon(Icons.add),
                  label: const Text('Entrada'),
                )
              : null,
          body: Builder(
            builder: (innerContext) => ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              children: [
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF52A9FF)),
                    title: const Text('Catálogo de materiais', style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: const Text('Consultar códigos em ordem e gerenciar materiais cadastrados'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Scaffold.of(innerContext).openEndDrawer(),
                  ),
                ),
                const SizedBox(height: 8),
                if (data.materials.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 50),
                    child: EmptyState(
                      icon: Icons.inventory_2_outlined,
                      title: 'Nenhum material em estoque',
                      subtitle: 'Use o catálogo para consultar os materiais cadastrados.',
                    ),
                  )
                else
                  for (final m in data.materials)
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.inventory_2_outlined, color: Color(0xFF52A9FF)),
                        title: Text(m.name),
                        subtitle: Text('${findTeam(data.teams, m.teamId)?.name ?? 'Local'} • ${m.code}'),
                        trailing: Text('${m.quantity} ${m.unit}',
                          style: const TextStyle(color: Color(0xFF52A9FF), fontWeight: FontWeight.w900)),
                        onTap: canOperate && (role == 'admin' || role == 'engineer' || m.teamId == userTeamId)
                            ? () => showMaterialActionsDialog(context, repo, data.teams, m, role, userTeamId)
                            : null,
                      ),
                    ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class MaterialCatalogDrawer extends StatefulWidget {
  const MaterialCatalogDrawer({super.key, required this.repo, required this.isAdmin});
  final MetalloRepository repo;
  final bool isAdmin;

  @override
  State<MaterialCatalogDrawer> createState() => _MaterialCatalogDrawerState();
}

class _MaterialCatalogDrawerState extends State<MaterialCatalogDrawer> {
  late Future<List<Map<String, dynamic>>> catalog = widget.repo.fetchMaterialCatalog();
  void reload() => setState(() => catalog = widget.repo.fetchMaterialCatalog());

  @override
  Widget build(BuildContext context) => Drawer(
    width: MediaQuery.sizeOf(context).width * .90,
    backgroundColor: const Color(0xFF0A0F16),
    child: SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 8, 10),
            child: Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Catálogo de materiais', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                Text('Ordenado pelo código global', style: TextStyle(color: Colors.white60)),
              ])),
              IconButton(onPressed: reload, icon: const Icon(Icons.refresh)),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
            ]),
          ),
          const Divider(height: 1),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: catalog,
              builder: (context, snap) {
                if (snap.hasError) return ErrorState(error: snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.isEmpty) return const Center(child: Text('Nenhum material cadastrado.'));
                return ListView.separated(
                  padding: const EdgeInsets.all(10),
                  itemCount: snap.data!.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final m = snap.data![i];
                    return ListTile(
                      leading: Container(
                        constraints: const BoxConstraints(minWidth: 58),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                        decoration: BoxDecoration(color: const Color(0xFF0E3965), borderRadius: BorderRadius.circular(9)),
                        child: Text(m['code']?.toString() ?? '-', textAlign: TextAlign.center,
                          style: const TextStyle(color: Color(0xFF8CC8FF), fontWeight: FontWeight.w900)),
                      ),
                      title: Text(m['name']?.toString() ?? ''),
                      subtitle: Text('${m['unit'] ?? 'un'}${(m['category']?.toString().isNotEmpty ?? false) ? ' • ${m['category']}' : ''}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Total: ${(m['total_quantity'] as num?)?.toInt() ?? 0} ${m['unit'] ?? 'un'}',
                            style: const TextStyle(color: Color(0xFF89CFF0), fontWeight: FontWeight.w900),
                          ),
                          if (widget.isAdmin)
                            PopupMenuButton<String>(
                              onSelected: (value) async {
                                if (value == 'edit') {
                                  final changed = await showEditMaterialCatalogDialog(context, widget.repo, m);
                                  if (changed == true) reload();
                                } else if (value == 'delete') {
                                  final ok = await confirm(context, 'Excluir material?',
                                    'O material será retirado do catálogo. Por segurança, a exclusão só é permitida quando não houver saldo em nenhuma localização. O histórico será preservado.');
                                  if (ok == true) {
                                    try { await widget.repo.deactivateMaterialItem(m['id'].toString()); reload(); }
                                    catch (e) { if (context.mounted) showError(context, e); }
                                  }
                                }
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'edit', child: Text('Editar')),
                                PopupMenuItem(value: 'delete', child: Text('Excluir')),
                              ],
                            ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}

Future<bool?> showEditMaterialCatalogDialog(BuildContext context, MetalloRepository repo, Map<String, dynamic> material) async {
  final code = TextEditingController(text: material['code']?.toString() ?? '');
  final name = TextEditingController(text: material['name']?.toString() ?? '');
  final unit = TextEditingController(text: material['unit']?.toString() ?? 'un');
  final category = TextEditingController(text: material['category']?.toString() ?? '');
  final description = TextEditingController(text: material['description']?.toString() ?? '');
  bool busy = false; String? error;
  return showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
    builder: (context, setLocal) => AlertDialog(
      title: const Text('Editar material'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: code, decoration: const InputDecoration(labelText: 'Código global')),
        const SizedBox(height: 10), TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
        const SizedBox(height: 10), TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unidade')),
        const SizedBox(height: 10), TextField(controller: category, decoration: const InputDecoration(labelText: 'Categoria (opcional)')),
        const SizedBox(height: 10), TextField(controller: description, decoration: const InputDecoration(labelText: 'Descrição (opcional)')),
        if (error != null) ...[const SizedBox(height: 10), Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))],
      ])),
      actions: [
        TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
        FilledButton(onPressed: busy ? null : () async {
          final v = requiredText(code.text, 'Código') ?? requiredText(name.text, 'Nome');
          if (v != null) { setLocal(() => error = v); return; }
          setLocal(() { busy = true; error = null; });
          try {
            await repo.updateMaterialItem(itemId: material['id'].toString(), code: code.text, name: name.text,
              unit: unit.text, category: category.text, description: description.text);
            if (dialogContext.mounted) Navigator.pop(dialogContext, true);
          } catch (e) { setLocal(() => error = friendlyError(e)); }
          finally { if (dialogContext.mounted) setLocal(() => busy = false); }
        }, child: busy ? const CircularProgressIndicator(strokeWidth: 2) : const Text('Salvar')),
      ],
    ),
  ));
}

class EquipmentPage extends StatelessWidget {
  const EquipmentPage({
    super.key,
    required this.repo,
    required this.stream,
    required this.role,
    required this.userTeamId,
  });
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;
  final String role;
  final String? userTeamId;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) return ErrorState(error: snap.error);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final data = snap.data!;
        final canOperate = role == 'admin' || role == 'engineer' || role == 'leader';
        final allowedTeams = role == 'leader'
            ? data.teams.where((t) => t.id == userTeamId).toList()
            : data.teams;

        return Scaffold(
          backgroundColor: const Color(0xFF05080D),
          endDrawer: EquipmentCatalogDrawer(repo: repo),
          floatingActionButton: canOperate && allowedTeams.isNotEmpty
              ? FloatingActionButton.extended(
                  onPressed: () => showEquipmentDialog(
                    context,
                    repo,
                    allowedTeams,
                    role == 'leader' ? userTeamId : null,
                  ),
                  icon: const Icon(Icons.add),
                  label: const Text('Novo equipamento'),
                )
              : null,
          body: Builder(
            builder: (innerContext) => ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              children: [
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.menu_book_outlined, color: Colors.blueGrey),
                    title: const Text('Catálogo de equipamentos', style: TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: const Text('Consultar os códigos individuais dos equipamentos'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Scaffold.of(innerContext).openEndDrawer(),
                  ),
                ),
                const SizedBox(height: 8),
                if (data.equipment.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 50),
                    child: EmptyState(
                      icon: Icons.handyman_outlined,
                      title: 'Nenhum equipamento',
                      subtitle: 'Os equipamentos cadastrados aparecerão aqui.',
                    ),
                  )
                else
                  for (final e in data.equipment)
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.handyman_outlined),
                        title: Text(e.name),
                        subtitle: Text(
                          '${findTeam(data.teams, e.teamId)?.name ?? 'Equipe'} • código ${e.assetCode}',
                        ),
                        trailing: StatusBadge(status: e.status),
                        onTap: canOperate &&
                                (role == 'admin' || role == 'engineer' || e.teamId == userTeamId)
                            ? () => showEquipmentTransferDialog(
                                  context,
                                  repo,
                                  data.teams,
                                  e,
                                )
                            : null,
                      ),
                    ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class EquipmentCatalogDrawer extends StatefulWidget {
  const EquipmentCatalogDrawer({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<EquipmentCatalogDrawer> createState() => _EquipmentCatalogDrawerState();
}

class _EquipmentCatalogDrawerState extends State<EquipmentCatalogDrawer> {
  late Future<List<Map<String, dynamic>>> catalog = widget.repo.fetchEquipmentCatalog();
  void reload() => setState(() => catalog = widget.repo.fetchEquipmentCatalog());

  @override
  Widget build(BuildContext context) => Drawer(
        width: MediaQuery.sizeOf(context).width * .90,
        backgroundColor: const Color(0xFF0A0F16),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 8, 10),
                child: Row(
                  children: [
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Catálogo de equipamentos', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                          Text('Ordenado pelo código individual', style: TextStyle(color: Colors.white60)),
                        ],
                      ),
                    ),
                    IconButton(onPressed: reload, icon: const Icon(Icons.refresh)),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: FutureBuilder<List<Map<String, dynamic>>>(
                  future: catalog,
                  builder: (context, snap) {
                    if (snap.hasError) return ErrorState(error: snap.error);
                    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                    if (snap.data!.isEmpty) return const Center(child: Text('Nenhum equipamento cadastrado.'));
                    return ListView.separated(
                      padding: const EdgeInsets.all(10),
                      itemCount: snap.data!.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final e = snap.data![i];
                        final item = e['items'] as Map?;
                        final team = e['teams'] as Map?;
                        return ListTile(
                          leading: Container(
                            constraints: const BoxConstraints(minWidth: 62),
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                            decoration: BoxDecoration(
                              color: const Color(0xFF26313D),
                              borderRadius: BorderRadius.circular(9),
                            ),
                            child: Text(
                              e['asset_code']?.toString() ?? '-',
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Color(0xFFCFD8E3), fontWeight: FontWeight.w900),
                            ),
                          ),
                          title: Text(item?['name']?.toString() ?? 'Equipamento'),
                          subtitle: Text([
                            if ((item?['code']?.toString() ?? '').isNotEmpty) 'modelo ${item?['code']}',
                            if ((team?['name']?.toString() ?? '').isNotEmpty) team?['name'].toString(),
                            statusLabel(e['status']?.toString() ?? 'available'),
                          ].join(' • ')),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
}

class AdministrationPage extends StatelessWidget {
  const AdministrationPage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Administração')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const BrandLogo(height: 62),
          const SizedBox(height: 18),
          Card(
            child: ListTile(
              leading: const Icon(Icons.person_add_alt_1),
              title: const Text('Criar funcionário'),
              subtitle: const Text('Engenheiro, encarregado ou colaborador com equipe definida'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => CreateEmployeePage(repo: repo),
                ),
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.manage_accounts_outlined),
              title: const Text('Gerenciar usuários'),
              subtitle: const Text('Cargo, equipe e liberação de acesso'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => UsersManagementPage(repo: repo),
                ),
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.groups_2_outlined),
              title: const Text('Equipes'),
              subtitle: const Text('Criar, editar ou excluir'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => TeamsPage(repo: repo)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CreateEmployeePage extends StatefulWidget {
  const CreateEmployeePage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<CreateEmployeePage> createState() => _CreateEmployeePageState();
}

class _CreateEmployeePageState extends State<CreateEmployeePage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  String role = 'collaborator';
  String? teamId;
  bool busy = false;
  String? error;
  late Future<DashboardSnapshot> dashboard = widget.repo.fetchDashboard();

  Future<void> create() async {
    if (teamId == null) {
      setState(() => error = 'Selecione a equipe.');
      return;
    }
    if (name.text.trim().isEmpty || email.text.trim().isEmpty) {
      setState(() => error = 'Preencha nome e e-mail.');
      return;
    }
    if (password.text.length < 4) {
      setState(() => error = 'A senha temporária precisa ter 4 ou mais caracteres.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await widget.repo.createEmployee(
        fullName: name.text,
        email: email.text,
        password: password.text,
        role: role,
        teamId: teamId!,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Funcionário criado e liberado.')),
        );
        name.clear();
        email.clear();
        password.clear();
      }
    } catch (e) {
      if (mounted) setState(() => error = friendlyError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: widget.repo.watchDashboard(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final teams = snap.data!.teams;
        teamId ??= teams.isEmpty ? null : teams.first.id;

        return Scaffold(
          appBar: AppBar(title: const Text('Novo funcionário')),
          body: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 12),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'E-mail'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: password,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Senha temporária (4+)'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: role,
                decoration: const InputDecoration(labelText: 'Cargo'),
                items: const [
                  DropdownMenuItem(value: 'engineer', child: Text('Engenheiro')),
                  DropdownMenuItem(value: 'leader', child: Text('Encarregado')),
                  DropdownMenuItem(value: 'collaborator', child: Text('Colaborador')),
                ],
                onChanged: busy ? null : (v) => setState(() => role = v!),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: teamId,
                decoration: const InputDecoration(labelText: 'Equipe'),
                items: teams
                    .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                    .toList(),
                onChanged: busy ? null : (v) => setState(() => teamId = v),
              ),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 18),
              FilledButton(
                onPressed: busy ? null : create,
                child: busy
                    ? const CircularProgressIndicator(strokeWidth: 2)
                    : const Text('Criar funcionário'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class UsersManagementPage extends StatefulWidget {
  const UsersManagementPage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<UsersManagementPage> createState() => _UsersManagementPageState();
}

class _UsersManagementPageState extends State<UsersManagementPage> {
  late Future<List<Map<String, dynamic>>> users = widget.repo.fetchProfiles();
  late Future<DashboardSnapshot> dashboard = widget.repo.fetchDashboard();

  void reload() => setState(() => users = widget.repo.fetchProfiles());

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: widget.repo.watchDashboard(),
      builder: (context, teamSnap) {
        if (!teamSnap.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final teams = teamSnap.data!.teams;

        return Scaffold(
          appBar: AppBar(title: const Text('Usuários')),
          body: FutureBuilder<List<Map<String, dynamic>>>(
            future: users,
            builder: (context, snap) {
              if (snap.hasError) return ErrorState(error: snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  for (final user in snap.data!)
                    Card(
                      child: ListTile(
                        leading: Icon(
                          user['active'] == true
                              ? Icons.verified_user_outlined
                              : Icons.hourglass_empty,
                        ),
                        title: Text(user['full_name']?.toString() ?? 'Usuário'),
                        subtitle: Text(
                          '${roleLabel(user['role']?.toString() ?? 'collaborator')} • '
                          '${(user['teams'] as Map?)?['name'] ?? 'Sem equipe'} • '
                          '${user['active'] == true ? 'Ativo' : 'Aguardando liberação'}',
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (action) async {
                            if (action == 'edit') {
                              await showUserEditDialog(context, widget.repo, teams, user);
                              reload();
                            } else if (action == 'delete') {
                              final yes = await confirm(
                                context,
                                'Excluir usuário?',
                                'O acesso será removido permanentemente. O histórico operacional já registrado será preservado.',
                              );
                              if (yes == true) {
                                try {
                                  await widget.repo.deleteEmployee(user['id'].toString());
                                  reload();
                                } catch (e) {
                                  if (context.mounted) showError(context, e);
                                }
                              }
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('Editar')),
                            PopupMenuItem(value: 'delete', child: Text('Excluir')),
                          ],
                        ),
                        onTap: () async {
                          await showUserEditDialog(context, widget.repo, teams, user);
                          reload();
                        },
                      ),
                    ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class TeamsPage extends StatefulWidget {
  const TeamsPage({super.key, required this.repo});
  final MetalloRepository repo;

  @override
  State<TeamsPage> createState() => _TeamsPageState();
}

class _TeamsPageState extends State<TeamsPage> {
  late Future<DashboardSnapshot> future = widget.repo.fetchDashboard();

  void reload() => setState(() => future = widget.repo.fetchDashboard());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Equipes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await showTeamDialog(context, widget.repo);
          reload();
        },
        icon: const Icon(Icons.add),
        label: const Text('Criar equipe'),
      ),
      body: FutureBuilder<DashboardSnapshot>(
        future: future,
        builder: (context, snap) {
          if (snap.hasError) return ErrorState(error: snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final teams = snap.data!.teams;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                '${teams.where((t) => !t.isCentral).length} equipes de campo • COSEM separada',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              for (final t in teams)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.groups_2_outlined),
                    title: Text(t.name),
                    subtitle: t.description == null ? null : Text(t.description!),
                    trailing: PopupMenuButton<String>(
                      onSelected: (action) async {
                        if (action == 'edit') {
                          await showTeamDialog(context, widget.repo, team: t);
                          reload();
                        } else if (action == 'delete') {
                          final yes = await confirm(
                            context,
                            'Excluir equipe?',
                            'A equipe só poderá ser excluída se não tiver estoque, equipamentos ou usuários ativos.',
                          );
                          if (yes == true) {
                            try {
                              await widget.repo.deleteTeam(t.id);
                              reload();
                            } catch (e) {
                              if (context.mounted) showError(context, e);
                            }
                          }
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Editar')),
                        PopupMenuItem(value: 'delete', child: Text('Excluir')),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

Color historyAccentColor(bool isMaterial, String type) {
  if (!isMaterial) return Colors.blueGrey.shade300;
  switch (type) {
    case 'entry':
      return const Color(0xFF89CFF0); // azul bebê
    case 'replenishment':
      return const Color(0xFF38BDF8); // azul celeste
    case 'consumption':
      return const Color(0xFF4F8CFF);
    default:
      return const Color(0xFF52A9FF);
  }
}

class HistoryMovementIcon extends StatelessWidget {
  const HistoryMovementIcon({
    super.key,
    required this.isMaterial,
    required this.movementType,
    required this.color,
  });

  final bool isMaterial;
  final String movementType;
  final Color color;

  @override
  Widget build(BuildContext context) {
    if (!isMaterial) return Icon(Icons.handyman_outlined, color: color);
    if (movementType == 'entry') {
      return SizedBox(
        width: 42,
        height: 42,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(bottom: 1, child: Icon(Icons.inventory_2_outlined, color: color, size: 28)),
            Positioned(top: 0, child: Icon(Icons.arrow_downward_rounded, color: color, size: 19)),
          ],
        ),
      );
    }
    if (movementType == 'replenishment') {
      return SizedBox(
        width: 54,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined, color: color, size: 18),
            Icon(Icons.arrow_forward_rounded, color: color, size: 16),
            Icon(Icons.inventory_2_outlined, color: color, size: 18),
          ],
        ),
      );
    }
    if (movementType == 'consumption') {
      return Icon(Icons.remove_circle_outline_rounded, color: color, size: 30);
    }
    return Icon(Icons.inventory_2_outlined, color: color);
  }
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key, required this.repo, required this.stream, required this.isAdmin});
  final MetalloRepository repo;
  final Stream<DashboardSnapshot> stream;
  final bool isAdmin;

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  void reload() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DashboardSnapshot>(
      stream: widget.repo.watchDashboard(),
      builder: (context, dSnap) {
        if (!dSnap.hasData) return const Center(child: CircularProgressIndicator());
        final teams = dSnap.data!.teams;

        return FutureBuilder<List<Map<String, dynamic>>>(
          future: widget.repo.fetchHistory(),
          builder: (context, snap) {
            if (snap.hasError) return ErrorState(error: snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            if (snap.data!.isEmpty) {
              return const EmptyState(
                icon: Icons.history,
                title: 'Histórico vazio',
                subtitle: 'As entradas e movimentações aparecerão aqui.',
              );
            }
            return RefreshIndicator(
              onRefresh: () async {
                reload();
                await widget.repo.refreshDashboard();
              },
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: snap.data!.length,
                itemBuilder: (context, i) {
                  final row = snap.data![i];
                  final isMaterial = row['_kind'] == 'material';
                  final title = isMaterial
                      ? ((row['items'] as Map?)?['name']?.toString() ?? 'Material')
                      : (((row['assets'] as Map?)?['items'] as Map?)?['name']?.toString() ??
                          'Equipamento');
                  final origin = (row['origin'] as Map?)?['name']?.toString();
                  final destination = (row['destination'] as Map?)?['name']?.toString();
                  final movementType = row['movement_type']?.toString() ?? '';
                  final accent = historyAccentColor(isMaterial, movementType);
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(color: accent.withValues(alpha: .55)),
                    ),
                    child: ListTile(
                      leading: HistoryMovementIcon(
                        isMaterial: isMaterial,
                        movementType: movementType,
                        color: accent,
                      ),
                      title: Text(title),
                      subtitle: Text([
                        movementLabel(row['movement_type']?.toString() ?? ''),
                        if (origin != null) 'de $origin',
                        if (destination != null) 'para $destination',
                        if (isMaterial) '${row['quantity']} un',
                        if (row['note'] != null && row['note'].toString().isNotEmpty)
                          row['note'].toString(),
                      ].join(' • ')),
                      trailing: widget.isAdmin
                          ? PopupMenuButton<String>(
                              onSelected: (action) async {
                                if (action == 'edit') {
                                  try {
                                    if (isMaterial) {
                                      await showMaterialHistoryEdit(
                                        context,
                                        widget.repo,
                                        teams,
                                        row,
                                      );
                                    } else {
                                      await showAssetHistoryEdit(
                                        context,
                                        widget.repo,
                                        teams,
                                        row,
                                      );
                                    }
                                    reload();
                                  } catch (e) {
                                    if (context.mounted) showError(context, e);
                                  }
                                } else if (action == 'delete') {
                                  final yes = await confirm(
                                    context,
                                    'Excluir registro?',
                                    'A exclusão também desfaz o efeito desta movimentação no estoque/localização.',
                                  );
                                  if (yes == true) {
                                    try {
                                      if (isMaterial) {
                                        await widget.repo.deleteMaterialHistory(
                                          row['id'].toString(),
                                        );
                                      } else {
                                        await widget.repo.deleteAssetHistory(
                                          row['id'].toString(),
                                        );
                                      }
                                      reload();
                                    } catch (e) {
                                      if (context.mounted) showError(context, e);
                                    }
                                  }
                                }
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'edit', child: Text('Corrigir')),
                                PopupMenuItem(value: 'delete', child: Text('Excluir')),
                              ],
                            )
                          : null,
                    ),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }
}

Future<void> showMaterialDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  String? initialTeamId,
) async {
  final catalog = await repo.fetchMaterialCatalog();
  if (!context.mounted) return;

  final code = TextEditingController();
  final name = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final unit = TextEditingController(text: 'un');
  String? teamId = initialTeamId ?? (teams.isNotEmpty ? teams.first.id : null);
  bool existing = catalog.isNotEmpty;
  String? selectedId;
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Entrada de material'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (catalog.isNotEmpty) ...[
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: true, label: Text('Existente')),
                    ButtonSegment(value: false, label: Text('Novo')),
                  ],
                  selected: {existing},
                  onSelectionChanged: busy
                      ? null
                      : (v) => setLocal(() {
                            existing = v.first;
                            selectedId = null;
                            code.clear();
                            name.clear();
                            unit.text = 'un';
                          }),
                ),
                const SizedBox(height: 12),
              ],
              if (existing && catalog.isNotEmpty)
                DropdownButtonFormField<String>(
                  initialValue: selectedId,
                  decoration: const InputDecoration(labelText: 'Material cadastrado'),
                  items: catalog
                      .map(
                        (m) => DropdownMenuItem(
                          value: m['id'].toString(),
                          child: Text('${m['name']} • ${m['code']}'),
                        ),
                      )
                      .toList(),
                  onChanged: busy
                      ? null
                      : (v) {
                          final selected =
                              catalog.firstWhere((m) => m['id'].toString() == v);
                          setLocal(() {
                            selectedId = v;
                            code.text = selected['code']?.toString() ?? '';
                            name.text = selected['name']?.toString() ?? '';
                            unit.text = selected['unit']?.toString() ?? 'un';
                          });
                        },
                )
              else ...[
                TextField(
                  controller: code,
                  decoration: const InputDecoration(labelText: 'Código'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'Material'),
                ),
              ],
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: teamId,
                decoration: const InputDecoration(labelText: 'Equipe'),
                items: teams
                    .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                    .toList(),
                onChanged: busy ? null : (v) => setLocal(() => teamId = v),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: quantity,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Quantidade'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: unit,
                      enabled: !(existing && catalog.isNotEmpty),
                      decoration: const InputDecoration(labelText: 'Unidade'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Um material possui um único código. Cada equipe mantém apenas sua própria quantidade.',
                style: TextStyle(fontSize: 12, color: Colors.white60),
              ),
              if (error != null) ...[
                const SizedBox(height: 10),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final q = int.tryParse(quantity.text.trim());
                    final validation = (existing && catalog.isNotEmpty && selectedId == null)
                        ? 'Selecione um material.'
                        : requiredText(code.text, 'Código') ??
                            requiredText(name.text, 'Material') ??
                            (teamId == null ? 'Selecione uma equipe.' : null) ??
                            positiveQuantity(q);
                    if (validation != null) {
                      setLocal(() => error = validation);
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.createMaterial(
                        code: code.text,
                        name: name.text,
                        teamId: teamId!,
                        quantity: q!,
                        unit: unit.text,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Adicionar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showEquipmentDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  String? initialTeamId,
) async {
  final code = TextEditingController();
  final name = TextEditingController();
  final assetCode = TextEditingController();
  final serial = TextEditingController();
  String? teamId = initialTeamId ?? (teams.isNotEmpty ? teams.first.id : null);
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Novo equipamento'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: code, decoration: const InputDecoration(labelText: 'Código do tipo')),
              const SizedBox(height: 10),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Equipamento')),
              const SizedBox(height: 10),
              TextField(
                controller: assetCode,
                decoration: const InputDecoration(labelText: 'Patrimônio / identificação'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: serial,
                decoration: const InputDecoration(labelText: 'Número de série (opcional)'),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: teamId,
                decoration: const InputDecoration(labelText: 'Equipe'),
                items: teams
                    .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                    .toList(),
                onChanged: busy ? null : (v) => setLocal(() => teamId = v),
              ),
              const SizedBox(height: 8),
              const Text(
                'O código identifica o tipo/modelo; o patrimônio identifica o equipamento físico.',
                style: TextStyle(fontSize: 12, color: Colors.white60),
              ),
              if (error != null) ...[
                const SizedBox(height: 10),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final validation = requiredText(code.text, 'Código') ??
                        requiredText(name.text, 'Equipamento') ??
                        requiredText(assetCode.text, 'Patrimônio') ??
                        (teamId == null ? 'Selecione a equipe.' : null);
                    if (validation != null) {
                      setLocal(() => error = validation);
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.createEquipment(
                        code: code.text,
                        name: name.text,
                        assetCode: assetCode.text,
                        serialNumber: serial.text,
                        teamId: teamId!,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Criar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showMaterialActionsDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  MaterialStock material,
  String role,
  String? userTeamId,
) async {
  final current = findTeam(teams, material.teamId);
  final centralMatches = teams.where((t) => t.isCentral).toList();
  final central = centralMatches.isEmpty ? null : centralMatches.first;
  final canConsume = role == 'admin' || role == 'engineer' || material.teamId == userTeamId;
  final canReplenish = (role == 'admin' || role == 'engineer') && current?.isCentral == true && central != null;

  final action = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: Text(material.name),
            subtitle: Text('${current?.name ?? 'Local'} • ${material.quantity} ${material.unit}'),
          ),
          if (canConsume)
            ListTile(
              leading: const Icon(Icons.remove_circle_outline, color: Color(0xFF52A9FF)),
              title: const Text('Registrar consumo'),
              subtitle: const Text('Baixa o material desta localização.'),
              onTap: () => Navigator.pop(sheetContext, 'consume'),
            ),
          if (canReplenish)
            ListTile(
              leading: const Icon(Icons.local_shipping_outlined, color: Color(0xFF52A9FF)),
              title: const Text('Repor equipe'),
              subtitle: const Text('Move estoque da COSEM para uma equipe.'),
              onTap: () => Navigator.pop(sheetContext, 'replenish'),
            ),
          const SizedBox(height: 8),
        ],
      ),
    ),
  );
  if (!context.mounted || action == null) return;

  if (action == 'consume') {
    await showMaterialQuantityDialog(
      context,
      title: 'Consumo de ${material.name}',
      maximum: material.quantity,
      actionLabel: 'Registrar consumo',
      onConfirm: (quantity, note, _) => repo.consumeMaterial(
        itemId: material.itemId,
        teamId: material.teamId,
        quantity: quantity,
        note: note,
      ),
    );
  } else if (action == 'replenish' && central != null) {
    final destinations = teams.where((t) => !t.isCentral).toList();
    if (destinations.isEmpty) return;
    await showMaterialQuantityDialog(
      context,
      title: 'Reposição de ${material.name}',
      maximum: material.quantity,
      actionLabel: 'Repor equipe',
      destinations: destinations,
      onConfirm: (quantity, note, destinationTeamId) => repo.replenishMaterial(
        itemId: material.itemId,
        centralTeamId: central.id,
        destinationTeamId: destinationTeamId!,
        quantity: quantity,
        note: note,
      ),
    );
  }
}

Future<void> showMaterialQuantityDialog(
  BuildContext context, {
  required String title,
  required int maximum,
  required String actionLabel,
  List<Team>? destinations,
  required Future<void> Function(int quantity, String? note, String? destinationTeamId) onConfirm,
}) async {
  final qty = TextEditingController(text: '1');
  final note = TextEditingController();
  String? destinationTeamId = (destinations != null && destinations.isNotEmpty) ? destinations.first.id : null;
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (destinations != null && destinations.isNotEmpty) ...[
                DropdownButtonFormField<String>(
                  initialValue: destinationTeamId,
                  decoration: const InputDecoration(labelText: 'Equipe de destino'),
                  items: destinations
                      .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                      .toList(),
                  onChanged: busy ? null : (v) => setLocal(() => destinationTeamId = v),
                ),
                const SizedBox(height: 10),
              ],
              TextField(
                controller: qty,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Quantidade (máx. $maximum)'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: note,
                decoration: const InputDecoration(labelText: 'Observação (opcional)'),
              ),
              if (error != null) ...[
                const SizedBox(height: 10),
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final quantity = int.tryParse(qty.text);
                    if (quantity == null || quantity <= 0 || quantity > maximum) {
                      setLocal(() => error = 'Quantidade inválida.');
                      return;
                    }
                    if (destinations != null && destinationTeamId == null) {
                      setLocal(() => error = 'Selecione a equipe de destino.');
                      return;
                    }
                    setLocal(() { busy = true; error = null; });
                    try {
                      await onConfirm(quantity, note.text, destinationTeamId);
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: Text(actionLabel),
          ),
        ],
      ),
    ),
  );
}

Future<void> showEquipmentTransferDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  EquipmentAsset equipment,
) async {
  final destinations = teams.where((t) => t.id != equipment.teamId).toList();
  if (destinations.isEmpty) return;
  String to = destinations.first.id;
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text('Transferir ${equipment.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              initialValue: to,
              decoration: const InputDecoration(labelText: 'Equipe de destino'),
              items: destinations
                  .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                  .toList(),
              onChanged: busy ? null : (v) => setLocal(() => to = v!),
            ),
            if (error != null) ...[
              const SizedBox(height: 10),
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.transferEquipment(assetId: equipment.id, toTeamId: to);
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: const Text('Transferir'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showUserEditDialog(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  Map<String, dynamic> user,
) async {
  final name = TextEditingController(text: user['full_name']?.toString() ?? '');
  String role = user['role']?.toString() ?? 'collaborator';
  String? teamId = user['team_id']?.toString();
  bool active = user['active'] == true;
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Editar usuário'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: role,
                decoration: const InputDecoration(labelText: 'Cargo'),
                items: const [
                  DropdownMenuItem(value: 'admin', child: Text('Admin')),
                  DropdownMenuItem(value: 'engineer', child: Text('Engenheiro')),
                  DropdownMenuItem(value: 'leader', child: Text('Encarregado')),
                  DropdownMenuItem(value: 'collaborator', child: Text('Colaborador')),
                ],
                onChanged: busy ? null : (v) => setLocal(() => role = v!),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: teamId,
                decoration: const InputDecoration(labelText: 'Equipe'),
                items: teams
                    .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                    .toList(),
                onChanged: busy ? null : (v) => setLocal(() => teamId = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Acesso liberado'),
                value: active,
                onChanged: busy ? null : (v) => setLocal(() => active = v),
              ),
              if (error != null)
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    if (role != 'admin' && teamId == null) {
                      setLocal(() => error = 'Selecione uma equipe.');
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.updateProfileAdmin(
                        userId: user['id'].toString(),
                        fullName: name.text,
                        role: role,
                        teamId: role == 'admin' ? teamId : teamId,
                        active: active,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: const Text('Salvar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showTeamDialog(
  BuildContext context,
  MetalloRepository repo, {
  Team? team,
}) async {
  final name = TextEditingController(text: team?.name ?? '');
  final desc = TextEditingController(text: team?.description ?? '');
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: Text(team == null ? 'Nova equipe' : 'Editar equipe'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
            const SizedBox(height: 10),
            TextField(
              controller: desc,
              decoration: const InputDecoration(labelText: 'Descrição (opcional)'),
            ),
            if (error != null) ...[
              const SizedBox(height: 10),
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    if (name.text.trim().isEmpty) {
                      setLocal(() => error = 'Informe o nome.');
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      if (team == null) {
                        await repo.createTeam(name.text, desc.text);
                      } else {
                        await repo.updateTeam(team.id, name.text, desc.text);
                      }
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: Text(team == null ? 'Criar' : 'Salvar'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showMaterialHistoryEdit(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  Map<String, dynamic> row,
) async {
  final type = row['movement_type']?.toString() ?? 'entry';
  final qty = TextEditingController(text: row['quantity']?.toString() ?? '1');
  final note = TextEditingController(text: row['note']?.toString() ?? '');
  String? originId = row['origin_team_id']?.toString();
  String? destinationId = row['destination_team_id']?.toString();
  String? error;
  bool busy = false;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Corrigir movimentação'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: qty,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Quantidade'),
              ),
              if (type == 'transfer' || type == 'exit' || type == 'maintenance') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: originId,
                  decoration: const InputDecoration(labelText: 'Equipe de origem'),
                  items: teams
                      .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                      .toList(),
                  onChanged: busy ? null : (v) => setLocal(() => originId = v),
                ),
              ],
              if (type == 'transfer' || type == 'entry' || type == 'return') ...[
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: destinationId,
                  decoration: const InputDecoration(labelText: 'Equipe de destino'),
                  items: teams
                      .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                      .toList(),
                  onChanged: busy ? null : (v) => setLocal(() => destinationId = v),
                ),
              ],
              const SizedBox(height: 10),
              TextField(
                controller: note,
                decoration: const InputDecoration(labelText: 'Observação'),
              ),
              if (error != null)
                Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    final q = int.tryParse(qty.text);
                    if (q == null || q <= 0) {
                      setLocal(() => error = 'Quantidade inválida.');
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.updateMaterialHistory(
                        id: row['id'].toString(),
                        quantity: q,
                        originTeamId: originId,
                        destinationTeamId: destinationId,
                        note: note.text,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: const Text('Salvar correção'),
          ),
        ],
      ),
    ),
  );
}

Future<void> showAssetHistoryEdit(
  BuildContext context,
  MetalloRepository repo,
  List<Team> teams,
  Map<String, dynamic> row,
) async {
  String? teamId = row['destination_team_id']?.toString();
  String status = row['new_status']?.toString() ?? 'available';
  final note = TextEditingController(text: row['note']?.toString() ?? '');
  bool busy = false;
  String? error;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setLocal) => AlertDialog(
        title: const Text('Corrigir equipamento'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              initialValue: teamId,
              decoration: const InputDecoration(labelText: 'Equipe correta'),
              items: teams
                  .map((t) => DropdownMenuItem(value: t.id, child: Text(t.name)))
                  .toList(),
              onChanged: busy ? null : (v) => setLocal(() => teamId = v),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: status,
              decoration: const InputDecoration(labelText: 'Status'),
              items: const [
                DropdownMenuItem(value: 'available', child: Text('Disponível')),
                DropdownMenuItem(value: 'in_use', child: Text('Em uso')),
                DropdownMenuItem(value: 'maintenance', child: Text('Manutenção')),
                DropdownMenuItem(value: 'damaged', child: Text('Danificado')),
                DropdownMenuItem(value: 'lost', child: Text('Perdido')),
                DropdownMenuItem(value: 'retired', child: Text('Baixado')),
              ],
              onChanged: busy ? null : (v) => setLocal(() => status = v!),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: note,
              decoration: const InputDecoration(labelText: 'Observação'),
            ),
            if (error != null)
              Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: busy ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    if (teamId == null) {
                      setLocal(() => error = 'Selecione a equipe.');
                      return;
                    }
                    setLocal(() {
                      busy = true;
                      error = null;
                    });
                    try {
                      await repo.updateAssetHistory(
                        id: row['id'].toString(),
                        destinationTeamId: teamId!,
                        status: status,
                        note: note.text,
                      );
                      if (dialogContext.mounted) Navigator.pop(dialogContext);
                    } catch (e) {
                      setLocal(() => error = friendlyError(e));
                    } finally {
                      if (dialogContext.mounted) setLocal(() => busy = false);
                    }
                  },
            child: const Text('Salvar correção'),
          ),
        ],
      ),
    ),
  );
}

class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    return Chip(label: Text(statusLabel(status)));
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            Icon(icon, size: 64, color: const Color(0xFF1687FF)),
            const SizedBox(height: 14),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60),
            ),
          ],
        ),
      ),
    );
  }
}

class ErrorState extends StatelessWidget {
  const ErrorState({super.key, required this.error});
  final Object? error;

  @override
  Widget build(BuildContext context) {
    return EmptyState(
      icon: Icons.error_outline,
      title: 'Não foi possível carregar',
      subtitle: friendlyError(error),
    );
  }
}

class ErrorPage extends StatelessWidget {
  const ErrorPage({super.key, required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 64),
              const SizedBox(height: 14),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 18),
              FilledButton(onPressed: onRetry, child: const Text('Tentar novamente')),
              TextButton(
                onPressed: () => Supabase.instance.client.auth.signOut(),
                child: const Text('Sair'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Team? findTeam(List<Team> teams, String id) {
  for (final t in teams) {
    if (t.id == id) return t;
  }
  return null;
}

String firstName(String name) {
  final clean = name.trim();
  return clean.isEmpty ? 'Usuário' : clean.split(RegExp(r'\s+')).first;
}

String roleLabel(String role) {
  switch (role) {
    case 'admin':
      return 'Admin';
    case 'engineer':
      return 'Engenheiro';
    case 'leader':
      return 'Encarregado';
    default:
      return 'Colaborador';
  }
}

String statusLabel(String status) {
  const labels = {
    'available': 'Disponível',
    'in_use': 'Em uso',
    'maintenance': 'Manutenção',
    'damaged': 'Danificado',
    'lost': 'Perdido',
    'retired': 'Baixado',
  };
  return labels[status] ?? status;
}

String movementLabel(String type) {
  const labels = {
    'entry': 'Entrada',
    'exit': 'Saída',
    'transfer': 'Transferência',
    'return': 'Retorno',
    'maintenance': 'Manutenção',
    'assign': 'Atribuição',
    'status_change': 'Status',
    'consumption': 'Consumo',
    'replenishment': 'Reposição',
    'adjustment': 'Ajuste',
  };
  return labels[type] ?? type;
}

String friendlyError(Object? error) {
  final t = error.toString().replaceFirst('Exception: ', '');
  if (t.contains('email_not_confirmed') || t.toLowerCase().contains('email not confirmed')) {
    return 'Seu cadastro foi criado, mas o e-mail ainda não foi confirmado. Confirme pelo link enviado ao seu e-mail e, depois, aguarde a liberação do administrador.';
  }
  if (t.contains('invalid_credentials') || t.toLowerCase().contains('invalid login credentials')) {
    return 'E-mail ou senha incorretos.';
  }
  if (t.contains('user_already_exists') || t.toLowerCase().contains('user already registered')) {
    return 'Já existe uma conta cadastrada com este e-mail.';
  }
  if (t.contains('weak_password')) {
    return 'A senha não atende aos requisitos configurados no servidor.';
  }
  if (t.contains('admin_required')) return 'Apenas o administrador pode fazer isso.';
  if (t.contains('forbidden_role')) return 'Seu cargo não possui permissão para esta ação.';
  if (t.contains('forbidden_team') || t.contains('forbidden_origin_team')) {
    return 'Você só pode operar a sua própria equipe.';
  }
  if (t.contains('team_has_inventory')) return 'A equipe ainda possui materiais em estoque.';
  if (t.contains('team_has_assets')) return 'A equipe ainda possui equipamentos.';
  if (t.contains('team_has_active_users')) return 'A equipe ainda possui usuários ativos.';
  if (t.contains('only_latest_asset_movement_can_change')) {
    return 'Por segurança, somente a movimentação mais recente deste equipamento pode ser corrigida ou excluída.';
  }
  if (t.contains('cannot_reverse_destination_stock')) {
    return 'Não é possível desfazer este histórico porque o estoque atual já foi consumido ou transferido.';
  }
  if (t.contains('insufficient_stock')) return 'Quantidade insuficiente na localização de origem.';
  if (t.contains('item_has_stock')) return 'Não é possível excluir: este material ainda possui saldo em uma localização.';
  if (t.contains('item_has_assets')) return 'Não é possível excluir: este cadastro ainda possui equipamentos ativos.';
  if (t.contains('duplicate key') || t.contains('23505')) {
    return 'Este código ou patrimônio já está em uso.';
  }
  if (t.contains('SocketException') || t.contains('Failed host lookup')) {
    return 'Sem conexão com o servidor. Verifique sua internet.';
  }
  return t;
}

Future<bool?> confirm(BuildContext context, String title, String text) {
  return showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Text(text),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancelar'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Confirmar'),
        ),
      ],
    ),
  );
}

void showError(BuildContext context, Object error) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(friendlyError(error))),
  );
}
