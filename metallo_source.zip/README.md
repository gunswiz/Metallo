# Metallo – Marco 2

Objetivo desta versão:
- 4 equipes;
- materiais e equipamentos sempre vinculados a uma equipe;
- cadastro atômico no Supabase;
- sincronização em tempo real;
- transferências entre equipes;
- histórico;
- layout preto + azul;
- botões com tratamento de erro e sem travamento infinito.
