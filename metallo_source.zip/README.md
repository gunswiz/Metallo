# Almoxarifado Online

MVP Flutter conectado ao projeto Supabase já criado.

## Executar em uma máquina com Flutter

```bash
flutter create . --platforms=android,ios
flutter pub get
flutter test
flutter run
```

O aplicativo usa apenas a chave publicável do Supabase. Nenhuma chave administrativa está incluída.
