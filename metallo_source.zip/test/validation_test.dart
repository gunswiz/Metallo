import 'package:flutter_test/flutter_test.dart';
import 'package:metallo/validation.dart';

void main() {
  test('reject zero quantity', () {
    expect(validatePositiveQuantity(0), isNotNull);
  });

  test('accept positive quantity', () {
    expect(validatePositiveQuantity(1), isNull);
  });

  test('required field', () {
    expect(validateRequired('   ', 'Nome'), isNotNull);
    expect(validateRequired('Makita', 'Nome'), isNull);
  });
}
