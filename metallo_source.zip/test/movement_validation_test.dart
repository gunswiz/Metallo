import 'package:flutter_test/flutter_test.dart';
import 'package:almoxarifado_online/validation.dart';

void main() {
  test('valid transfer', () => expect(MovementValidation.transfer(2, 'A', 'B'), isNull));
  test('reject zero', () => expect(MovementValidation.transfer(0, 'A', 'B'), 'invalid_quantity'));
  test('reject same team', () => expect(MovementValidation.transfer(1, 'A', 'A'), 'same_team'));
}
