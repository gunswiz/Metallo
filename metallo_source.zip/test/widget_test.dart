import 'package:flutter_test/flutter_test.dart';

void main() {
  test('bootstrap sanity', () {
    expect(true, isTrue);
  });
}
