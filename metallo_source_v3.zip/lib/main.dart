import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabasePublishableKey,
  );
  runApp(const AlmoxApp());
}

class AlmoxApp extends StatelessWidget {
  const AlmoxApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Almoxarifado Online',
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
        home: AuthGate(repo: AppRepository(Supabase.instance.client)),
      );
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key, required this.repo});
  final AppRepository repo;
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  StreamSubscription<AuthState>? sub;
  @override
  void initState() {
    super.initState();
    sub = widget.repo.authChanges.listen((_) { if (mounted) setState(() {}); });
  }
  @override
  void dispose() { sub?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) => widget.repo.user == null
      ? LoginPage(repo: widget.repo)
      : HomePage(repo: widget.repo);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key, required this.repo});
  final AppRepository repo;
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool bootstrap = false, busy = false;
  String? msg;

  Future<void> submit() async {
    setState(() { busy = true; msg = null; });
    try {
      if (bootstrap) {
        await widget.repo.signUpFirstAdmin(name.text, email.text, password.text);
        if (widget.repo.user == null) msg = 'Confirme o e-mail e depois faça login.';
      } else {
        await widget.repo.signIn(email.text, password.text);
        try { await widget.repo.claimInitialAdmin(); } catch (_) {}
      }
    } on AuthException catch (e) { msg = e.message; }
    catch (e) { msg = '$e'; }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.inventory_2_outlined, size: 64),
          const SizedBox(height: 16),
          Text('Almoxarifado Online', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 24),
          if (bootstrap) ...[
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome completo', border: OutlineInputBorder())),
            const SizedBox(height: 12),
          ],
          TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha', border: OutlineInputBorder())),
          const SizedBox(height: 16),
          FilledButton(onPressed: busy ? null : submit, child: Text(bootstrap ? 'Criar primeiro administrador' : 'Entrar')),
          TextButton(onPressed: busy ? null : () => setState(() => bootstrap = !bootstrap), child: Text(bootstrap ? 'Já tenho conta' : 'Configurar primeiro administrador')),
          if (msg != null) Text(msg!, textAlign: TextAlign.center),
        ],
      )),
    ))),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.repo});
  final AppRepository repo;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late Future<Map<String, dynamic>> init;
  @override
  void initState() { super.initState(); init = load(); }
  Future<Map<String, dynamic>> load() async => {
    'profile': await widget.repo.profile(),
    'teams': await widget.repo.teams(),
    'items': await widget.repo.items(),
  };
  void refresh() => setState(() => init = load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
    future: init,
    builder: (context, snap) {
      if (snap.connectionState != ConnectionState.done) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      if (snap.hasError) {
        return Scaffold(
          appBar: AppBar(title: const Text('Almoxarifado Online')),
          body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Usuário inativo ou acesso não liberado.'),
            Text('${snap.error}'),
            FilledButton(onPressed: refresh, child: const Text('Tentar novamente')),
            TextButton(onPressed: widget.repo.signOut, child: const Text('Sair')),
          ])),
        );
      }
      final data = snap.data!;
      final profile = data['profile'] as Map<String, dynamic>;
      final teams = data['teams'] as List<Map<String, dynamic>>;
      final items = data['items'] as List<Map<String, dynamic>>;
      final teamNames = {for (final t in teams) t['id'] as String: t['name'] as String};
      final itemNames = {for (final i in items) i['id'] as String: i['name'] as String};
      final itemCodes = {for (final i in items) i['id'] as String: i['code'] as String};
      final isAdmin = profile['role'] == 'admin';
      final pages = [
        Dashboard(repo: widget.repo),
        Materials(repo: widget.repo, teamNames: teamNames, itemNames: itemNames, itemCodes: itemCodes),
        Equipment(repo: widget.repo, teamNames: teamNames, itemNames: itemNames),
        History(repo: widget.repo, teamNames: teamNames, itemNames: itemNames),
      ];
      return Scaffold(
        appBar: AppBar(title: Text('Olá, ${profile['full_name']}'), actions: [
          if (isAdmin) IconButton(onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(repo: widget.repo, teams: teams, items: items))); refresh(); }, icon: const Icon(Icons.admin_panel_settings_outlined)),
          IconButton(onPressed: refresh, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: widget.repo.signOut, icon: const Icon(Icons.logout)),
        ]),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab=i), destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Materiais'),
          NavigationDestination(icon: Icon(Icons.handyman_outlined), label: 'Equipamentos'),
          NavigationDestination(icon: Icon(Icons.history), label: 'Histórico'),
        ]),
      );
    },
  );
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key, required this.repo});
  final AppRepository repo;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    StreamBuilder<List<Map<String,dynamic>>>(stream: repo.inventory(), builder: (_, s) {
      final total=(s.data??const []).fold<int>(0,(a,b)=>a+((b['quantity'] as num?)?.toInt()??0));
      return Card(child: ListTile(leading: const Icon(Icons.inventory_2), title: const Text('Materiais em estoque'), trailing: Text('$total')));
    }),
    StreamBuilder<List<Map<String,dynamic>>>(stream: repo.assets(), builder: (_, s) {
      final rows=s.data??const []; final maint=rows.where((e)=>e['status']=='maintenance').length;
      return Card(child: ListTile(leading: const Icon(Icons.handyman), title: const Text('Equipamentos'), subtitle: Text('$maint em manutenção'), trailing: Text('${rows.length}')));
    }),
    const Card(child: ListTile(title: Text('Sincronização em tempo real'), subtitle: Text('Alterações feitas em uma equipe aparecem nos demais aparelhos conectados.'))),
  ]);
}

class Materials extends StatelessWidget {
  const Materials({
    super.key,
    required this.repo,
    required this.teamNames,
    required this.itemNames,
    required this.itemCodes,
  });

  final AppRepository repo;
  final Map<String, String> teamNames, itemNames, itemCodes;

  Future<void> _transfer(BuildContext context, Map<String, dynamic> row) async {
    final origin = row['team_id'] as String?;
    if (origin == null) return;
    final destinations = teamNames.entries.where((e) => e.key != origin).toList();
    if (destinations.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cadastre outra equipe para realizar transferências.')),
      );
      return;
    }
    String destination = destinations.first.key;
    final quantity = TextEditingController(text: '1');
    final note = TextEditingController();
    String? error;
    bool busy = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Transferir ${itemNames[row['item_id']] ?? 'material'}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Origem: ${teamNames[origin] ?? 'Equipe'} • Disponível: ${row['quantity']}'),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: destination,
                  decoration: const InputDecoration(labelText: 'Destino'),
                  items: destinations
                      .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                      .toList(),
                  onChanged: busy ? null : (v) => v == null ? null : setState(() => destination = v),
                ),
                TextField(
                  controller: quantity,
                  enabled: !busy,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Quantidade'),
                ),
                TextField(
                  controller: note,
                  enabled: !busy,
                  decoration: const InputDecoration(labelText: 'Observação (opcional)'),
                ),
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(error!),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      final q = int.tryParse(quantity.text.trim());
                      if (q == null || q <= 0) {
                        setState(() => error = 'Informe uma quantidade válida.');
                        return;
                      }
                      if (q > ((row['quantity'] as num?)?.toInt() ?? 0)) {
                        setState(() => error = 'Quantidade maior que o estoque disponível.');
                        return;
                      }
                      setState(() { busy = true; error = null; });
                      try {
                        await repo.transferMaterial(
                          itemId: row['item_id'] as String,
                          quantity: q,
                          originTeamId: origin,
                          destinationTeamId: destination,
                          note: note.text.trim().isEmpty ? null : note.text.trim(),
                        );
                        if (dialogContext.mounted) Navigator.pop(dialogContext);
                      } catch (e) {
                        setState(() { busy = false; error = 'Falha na transferência: $e'; });
                      }
                    },
              child: const Text('Transferir'),
            ),
          ],
        ),
      ),
    );
    quantity.dispose();
    note.dispose();
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: repo.inventory(),
        builder: (_, s) {
          if (s.hasError) return Center(child: Text('Erro ao carregar estoque: ${s.error}'));
          final rows = s.data ?? const [];
          if (rows.isEmpty) return const Center(child: Text('Nenhum material em estoque.'));
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: rows.length,
            itemBuilder: (_, i) {
              final r = rows[i];
              return Card(
                child: ListTile(
                  title: Text(itemNames[r['item_id']] ?? 'Material'),
                  subtitle: Text('${itemCodes[r['item_id']] ?? ''} • ${teamNames[r['team_id']] ?? 'Equipe'}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('${r['quantity']}'),
                      const SizedBox(width: 4),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                  onTap: () => _transfer(context, r),
                ),
              );
            },
          );
        },
      );
}

class Equipment extends StatelessWidget {
  const Equipment({
    super.key,
    required this.repo,
    required this.teamNames,
    required this.itemNames,
  });

  final AppRepository repo;
  final Map<String, String> teamNames, itemNames;

  static const statuses = <String, String>{
    'available': 'Disponível',
    'in_use': 'Em uso',
    'maintenance': 'Manutenção',
    'damaged': 'Danificado',
    'lost': 'Perdido',
  };

  Future<void> _manage(BuildContext context, Map<String, dynamic> row) async {
    final currentTeam = row['team_id'] as String?;
    String? destination = currentTeam;
    String status = (row['status'] as String?) ?? 'available';
    final note = TextEditingController();
    String? error;
    bool busy = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('${itemNames[row['item_id']] ?? 'Equipamento'} • ${row['asset_code']}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String?>(
                  initialValue: destination,
                  decoration: const InputDecoration(labelText: 'Equipe'),
                  items: [
                    const DropdownMenuItem<String?>(value: null, child: Text('Sem equipe')),
                    ...teamNames.entries.map((e) => DropdownMenuItem<String?>(value: e.key, child: Text(e.value))),
                  ],
                  onChanged: busy ? null : (v) => setState(() => destination = v),
                ),
                DropdownButtonFormField<String>(
                  initialValue: status,
                  decoration: const InputDecoration(labelText: 'Status'),
                  items: statuses.entries
                      .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                      .toList(),
                  onChanged: busy ? null : (v) => v == null ? null : setState(() => status = v),
                ),
                TextField(
                  controller: note,
                  enabled: !busy,
                  decoration: const InputDecoration(labelText: 'Observação (opcional)'),
                ),
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(error!),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      setState(() { busy = true; error = null; });
                      try {
                        final noteValue = note.text.trim().isEmpty ? null : note.text.trim();
                        if (destination != currentTeam) {
                          if (destination == null) {
                            throw Exception('Selecione uma equipe de destino para transferir.');
                          }
                          await repo.transferAsset(
                            assetId: row['id'] as String,
                            destinationTeamId: destination!,
                            newStatus: status,
                            note: noteValue,
                          );
                        } else if (status != row['status']) {
                          await repo.updateAssetStatus(
                            assetId: row['id'] as String,
                            newStatus: status,
                            note: noteValue,
                          );
                        }
                        if (dialogContext.mounted) Navigator.pop(dialogContext);
                      } catch (e) {
                        setState(() { busy = false; error = 'Falha ao atualizar: $e'; });
                      }
                    },
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
    note.dispose();
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: repo.assets(),
        builder: (_, s) {
          if (s.hasError) return Center(child: Text('Erro ao carregar equipamentos: ${s.error}'));
          final rows = s.data ?? const [];
          if (rows.isEmpty) return const Center(child: Text('Nenhum equipamento cadastrado.'));
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: rows.length,
            itemBuilder: (_, i) {
              final r = rows[i];
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.qr_code_2),
                  title: Text(itemNames[r['item_id']] ?? 'Equipamento'),
                  subtitle: Text('${r['asset_code']} • ${teamNames[r['team_id']] ?? 'Sem equipe'} • ${statuses[r['status']] ?? r['status']}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _manage(context, r),
                ),
              );
            },
          );
        },
      );
}

class History extends StatelessWidget {
  const History({
    super.key,
    required this.repo,
    required this.teamNames,
    required this.itemNames,
  });

  final AppRepository repo;
  final Map<String, String> teamNames, itemNames;

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: repo.movements(),
        builder: (context, materialSnapshot) => StreamBuilder<List<Map<String, dynamic>>>(
          stream: repo.assetMovements(),
          builder: (context, assetSnapshot) {
            if (materialSnapshot.hasError || assetSnapshot.hasError) {
              return Center(child: Text('Erro ao carregar histórico: ${materialSnapshot.error ?? assetSnapshot.error}'));
            }
            final rows = <Map<String, dynamic>>[
              ...(materialSnapshot.data ?? const []).map((e) => {...e, '_kind': 'material'}),
              ...(assetSnapshot.data ?? const []).map((e) => {...e, '_kind': 'asset'}),
            ]..sort((a, b) => '${b['created_at']}'.compareTo('${a['created_at']}'));
            if (rows.isEmpty) return const Center(child: Text('Sem movimentações.'));
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: rows.length,
              itemBuilder: (_, i) {
                final r = rows[i];
                final material = r['_kind'] == 'material';
                final origin = teamNames[r['origin_team_id']] ?? 'Sem origem';
                final destination = teamNames[r['destination_team_id']] ?? 'Sem destino';
                return ListTile(
                  leading: Icon(material ? Icons.inventory_2_outlined : Icons.handyman_outlined),
                  title: Text(material
                      ? '${r['movement_type']} • ${itemNames[r['item_id']] ?? 'Material'}'
                      : '${r['movement_type']} • Patrimônio ${('${r['asset_id']}').substring(0, 8)}'),
                  subtitle: Text(material
                      ? '$origin → $destination • ${r['quantity']}'
                      : '$origin → $destination • ${r['new_status'] ?? ''}'),
                );
              },
            );
          },
        ),
      );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key, required this.repo, required this.teams, required this.items});
  final AppRepository repo; final List<Map<String,dynamic>> teams,items;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Administração')),
    body: ListView(children: [
      ListTile(leading: const Icon(Icons.group_add), title: const Text('Criar funcionário'), onTap: () => _userDialog(context)),
      ListTile(leading: const Icon(Icons.groups), title: const Text('Criar equipe'), onTap: () => _teamDialog(context)),
      ListTile(leading: const Icon(Icons.inventory), title: const Text('Cadastrar material'), onTap: () => _itemDialog(context,'material')),
      ListTile(leading: const Icon(Icons.build), title: const Text('Cadastrar tipo de equipamento'), onTap: () => _itemDialog(context,'equipment')),
      ListTile(leading: const Icon(Icons.qr_code_2), title: const Text('Cadastrar patrimônio'), onTap: () => _assetDialog(context)),
    ]),
  );

  Future<void> _teamDialog(BuildContext context) async { final c=TextEditingController(); await showDialog(context: context,builder:(d)=>AlertDialog(title:const Text('Nova equipe'),content:TextField(controller:c),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancelar')),FilledButton(onPressed:()async{await repo.createTeam(c.text);if(d.mounted)Navigator.pop(d);},child:const Text('Criar'))])); c.dispose(); }
  Future<void> _itemDialog(BuildContext context,String type) async { final code=TextEditingController(),name=TextEditingController(); await showDialog(context: context,builder:(d)=>AlertDialog(title:Text(type=='material'?'Novo material':'Novo equipamento'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:code,decoration:const InputDecoration(labelText:'Código')),TextField(controller:name,decoration:const InputDecoration(labelText:'Nome'))]),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancelar')),FilledButton(onPressed:()async{await repo.createItem(code.text,name.text,type);if(d.mounted)Navigator.pop(d);},child:const Text('Criar'))])); code.dispose();name.dispose(); }
  Future<void> _assetDialog(BuildContext context) async { final eq=items.where((i)=>i['item_type']=='equipment').toList(); if(eq.isEmpty)return;String item=eq.first['id'];String? team=teams.isEmpty?null:teams.first['id'];final code=TextEditingController();await showDialog(context:context,builder:(d)=>StatefulBuilder(builder:(c,setS)=>AlertDialog(title:const Text('Novo patrimônio'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(initialValue:item,items:eq.map((e)=>DropdownMenuItem(value:e['id'] as String,child:Text(e['name'] as String))).toList(),onChanged:(v){if(v!=null)setS(()=>item=v);}),TextField(controller:code,decoration:const InputDecoration(labelText:'Código do patrimônio')),if(teams.isNotEmpty)DropdownButtonFormField<String>(initialValue:team,items:teams.map((e)=>DropdownMenuItem(value:e['id'] as String,child:Text(e['name'] as String))).toList(),onChanged:(v)=>setS(()=>team=v))]),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancelar')),FilledButton(onPressed:()async{await repo.createAsset(item,code.text,team);if(d.mounted)Navigator.pop(d);},child:const Text('Criar'))])));code.dispose();}
  Future<void> _userDialog(BuildContext context) async { final email=TextEditingController(),name=TextEditingController(),pass=TextEditingController();String role='collaborator';String? team=teams.isEmpty?null:teams.first['id'];await showDialog(context:context,builder:(d)=>StatefulBuilder(builder:(c,setS)=>AlertDialog(title:const Text('Novo funcionário'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Nome')),TextField(controller:email,decoration:const InputDecoration(labelText:'E-mail')),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Senha temporária (10+)')),DropdownButtonFormField<String>(initialValue:role,items:const[DropdownMenuItem(value:'collaborator',child:Text('Colaborador')),DropdownMenuItem(value:'leader',child:Text('Líder')),DropdownMenuItem(value:'admin',child:Text('Administrador'))],onChanged:(v){if(v!=null)setS(()=>role=v);}),if(teams.isNotEmpty)DropdownButtonFormField<String>(initialValue:team,items:teams.map((e)=>DropdownMenuItem(value:e['id'] as String,child:Text(e['name'] as String))).toList(),onChanged:(v)=>setS(()=>team=v))])),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Cancelar')),FilledButton(onPressed:()async{await repo.createUser(email:email.text,fullName:name.text,role:role,temporaryPassword:pass.text,teamId:team);if(d.mounted)Navigator.pop(d);},child:const Text('Criar'))])));email.dispose();name.dispose();pass.dispose();}
}
